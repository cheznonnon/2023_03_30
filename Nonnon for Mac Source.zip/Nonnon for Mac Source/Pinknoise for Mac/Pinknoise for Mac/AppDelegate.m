//
//  AppDelegate.m
//  Pinknoise for Mac
//
//  Created by nonnon on 2022/07/05.
//

#import "AppDelegate.h"


#import "../../nonnon/mac/sound.c"
#import "../../nonnon/mac/window.c"





@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;
@property (strong) IBOutlet NSButton *button;

@end

@implementation AppDelegate {

	//NSTimer       *timer;
	AVAudioPlayer *player;
	BOOL           onoff;

}

-(void) n_timer: (NSTimer*) timer
{
	//n_mac_timer_exit( timer );
	//n_mac_window_dialog_ok( "Done" );
	
}

- (IBAction)n_button_pressed:(id)sender
{
//NSLog( @"!" );

	if ( onoff )
	{
		onoff = FALSE;
		n_mac_sound_pause( player );
		[sender setTitle: @"Play"];
	} else {
		onoff = TRUE;
		n_mac_sound_play ( player );
		[sender setTitle: @"Pause"];
	}
	
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

	//[[self window] miniaturize:self];
	
	player = n_mac_sound_wav_init( @"pinknoise" );

	// [!] : repeat forever : gapless playback is very useful
	n_mac_sound_loop_count( player, -1 );

	n_mac_sound_play( player );


	// [!] : timer is not needed
	//timer = n_mac_timer_init( self, @selector( n_timer: ), 5000 );


	// [!] : check routine
	onoff = TRUE;


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
	
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		n_mac_sound_stop( player );
		[NSApp terminate:self];
	}
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end
