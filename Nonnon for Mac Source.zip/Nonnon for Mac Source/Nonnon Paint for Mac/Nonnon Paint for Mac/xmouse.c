// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@interface NonnonPaintStub : NSView

@property (nonatomic,assign) id delegate;
@property (nonatomic,assign) id delegate_canvas;

@end


@implementation NonnonPaintStub


@synthesize delegate;
@synthesize delegate_canvas;


- init
{
	self = [super init];
	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
	}

	return self;
}




- (void) updateTrackingAreas
{
//return;

	int options = (
		NSTrackingMouseEnteredAndExited |
		NSTrackingMouseMoved            |
		NSTrackingActiveAlways          |
		NSTrackingActiveInActiveApp
	);

	NSTrackingArea *trackingArea = [
		[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:options
			       owner:self
			    userInfo:nil
	];
	
	[self addTrackingArea:trackingArea];

}

- (void) mouseEntered:(NSEvent *)theEvent
{
//NSLog(@"mouseEntered");

	// [Needed] : NSTrackingMouseEnteredAndExited

	if ( self.window.keyWindow == FALSE )
	{
		[self.window makeKeyWindow];
	}

}

- (void) mouseExited:(NSEvent *)theEvent
{
//NSLog(@"mouseExited");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self.delegate_canvas resetCursorRects];

}




- (void) mouseUp:(NSEvent *)theEvent
{
//NSLog(@"XMouse : mouseUp");

	[self.delegate mouseUp:theEvent];

	[super mouseUp:theEvent];

}

- (void) mouseDragged:(NSEvent *)theEvent
{
//NSLog(@"! mouseDragged");

	// [!] : without this, mouse capture doesn't work

	[self.delegate mouseDragged:theEvent];


	// [Needed] : Tool Window Scroller : you cannot drag a thumb

	[super mouseDragged:theEvent];

}




- (void) otherMouseUp:(NSEvent *)theEvent
{
//NSLog(@"XMouse : mouseUp");

	[self.delegate otherMouseUp:theEvent];

}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	if ( n_paint_global.paint->readonly                                ) { return NSDragOperationNone; }
	if ( n_paint_global.paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL ) { return NSDragOperationNone; }

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	if ( n_paint_global.paint->readonly                                ) { return NO; }
	if ( n_paint_global.paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL ) { return NO; }

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	if ( n_paint_global.paint->readonly                                ) { return NO; }
	if ( n_paint_global.paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL ) { return NO; }

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

	[self.delegate NonnonDragAndDrop_dropped:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	if ( n_paint_global.paint->readonly                                ) { return NSDragOperationNone; }
	if ( n_paint_global.paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL ) { return NSDragOperationNone; }

	return NSDragOperationCopy;
}




@end


