// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_progressbar.c"

#include "../nonnon/project/macro.c"




#define N_X64_SYNC_TIMER_ID   (   1 )
#define N_X64_SYNC_TIMER_MSEC ( 500 )




const n_posix_bool debug_onoff = n_posix_false;//n_posix_true;
const u32          debug_msec  = 200;


static int n_x64_sync_count = 0;
static int n_x64_sync_index = 0;

static n_posix_bool n_x64_sync_timer_onoff = n_posix_false;




void
n_x64_sync_apps( HWND hwnd, n_posix_bool count_only )
{


	n_posix_char *f[] = {
		"Z:\\c\\arcdrop",
		"Z:\\c\\gameconsole",
		"Z:\\c\\nonnonapps",

		"Z:\\c\\cr2",
		"Z:\\c\\hunyapiyo2",
		"Z:\\c\\hunyapiyo3",
		"Z:\\c\\lm2",
		"Z:\\c\\nfreecell",
		"Z:\\c\\ngame",
		"Z:\\c\\nn",
		"Z:\\c\\nnrpg",
		"Z:\\c\\nspider",

		"Z:\\c\\calendar",
		"Z:\\c\\catpad",
		"Z:\\c\\charactermap",
		"Z:\\c\\felis",
		"Z:\\c\\marie",
		"Z:\\c\\n_attrib",
		"Z:\\c\\neko_no_te",
		"Z:\\c\\nmemo",
		"Z:\\c\\nmidi",
		"Z:\\c\\nmixer",
		"Z:\\c\\nonnon paint",
		"Z:\\c\\ntyping",
		"Z:\\c\\nyaurism",
		"Z:\\c\\orangecat",
		"Z:\\c\\pentrainer",
		"Z:\\c\\projectchecker",
		"Z:\\c\\watchcat",
		"Z:\\c\\wheel_axl",
		NULL
	};

	n_posix_char *t[] = {
		"C:\\VC++\\ArcDrop\\ArcDrop",
		"C:\\VC++\\GameConsole\\GameConsole",
		"C:\\VC++\\NonnonApps\\NonnonApps",

		"C:\\VC++\\GameConsole\\cr2",
		"C:\\VC++\\GameConsole\\hunyapiyo2",
		"C:\\VC++\\GameConsole\\hunyapiyo3",
		"C:\\VC++\\GameConsole\\lm2",
		"C:\\VC++\\GameConsole\\nfreecell",
		"C:\\VC++\\GameConsole\\ngame",
		"C:\\VC++\\GameConsole\\nn",
		"C:\\VC++\\GameConsole\\nnrpg",
		"C:\\VC++\\GameConsole\\nspider",

		"C:\\VC++\\NonnonApps\\calendar",
		"C:\\VC++\\NonnonApps\\catpad",
		"C:\\VC++\\NonnonApps\\charactermap",
		"C:\\VC++\\NonnonApps\\felis",
		"C:\\VC++\\NonnonApps\\marie",
		"C:\\VC++\\NonnonApps\\n_attrib",
		"C:\\VC++\\NonnonApps\\neko_no_te",
		"C:\\VC++\\NonnonApps\\nmemo",
		"C:\\VC++\\NonnonApps\\nmidi",
		"C:\\VC++\\NonnonApps\\nmixer",
		"C:\\VC++\\NonnonApps\\nonnon paint",
		"C:\\VC++\\NonnonApps\\ntyping",
		"C:\\VC++\\NonnonApps\\nyaurism",
		"C:\\VC++\\NonnonApps\\orangecat",
		"C:\\VC++\\NonnonApps\\pentrainer",
		"C:\\VC++\\NonnonApps\\projectchecker",
		"C:\\VC++\\NonnonApps\\watchcat",
		"C:\\VC++\\NonnonApps\\wheel_axl",
		NULL
	};


	int i = 0;
	while( 1 )
	{

		if ( count_only )
		{

			n_x64_sync_count++;

		} else {

			if ( debug_onoff )
			{
				n_posix_sleep( debug_msec );
			} else {
				n_filer_merge( f[ i ], t[ i ] );
			}

			n_posix_char name[ 1024 ]; n_path_name( t[ i ], name );

			n_x64_sync_index++;
			n_win_hwndprintf_literal( hwnd, "%d/%d : Apps : %s", n_x64_sync_index, n_x64_sync_count, name );
			n_win_message_send( hwnd, WM_PAINT, 0, 0 );

		}


		i++;
		if ( t[ i ] == NULL ) { break; }
	}

}

void
n_x64_sync_base( HWND hwnd, n_posix_bool count_only )
{

	n_posix_char *f = "Z:\\c\\nonnon";

	n_posix_char *t[] = {
		"C:\\VC++\\ArcDrop",
		"C:\\VC++\\GameConsole",
		"C:\\VC++\\NonnonApps",
		NULL
	};


	int i = 0;
	while( 1 )
	{

		n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "%s\\nonnon", t[ i ] );

		if ( count_only )
		{

			n_x64_sync_count++;

		} else {

			if ( debug_onoff )
			{
				n_posix_sleep( debug_msec );
			} else {
				n_filer_merge( f, str );
//n_posix_debug_literal( "%s", str );
			}

			n_posix_char name[ 1024 ]; n_path_name( t[ i ], name );

			n_x64_sync_index++;
			n_win_hwndprintf_literal( hwnd, "%d/%d : Base : %s", n_x64_sync_index, n_x64_sync_count, name );
			n_win_message_send( hwnd, WM_PAINT, 0, 0 );

		}


		i++;
		if ( t[ i ] == NULL ) { break; }
	}


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui = NULL;


	switch( msg ) {


	case WM_CREATE :

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		n_win_init_literal( hwnd, "x64 Sync", "A", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "Click Here", &hgui );
		n_win_stdfont_init( &hgui, 1 );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		{
			s32 ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );

			n_win_set( hwnd, NULL, 256,ctl*2, N_WIN_SET_CENTERING );
			MoveWindow( hgui, ctl/2,ctl/2,256-ctl,ctl, n_posix_true );
		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :

		n_win_cursor_add( NULL, IDC_WAIT );

		n_x64_sync_count = 0;
		n_x64_sync_index = 0;

		n_x64_sync_base( hgui, n_posix_true );
		n_x64_sync_apps( hgui, n_posix_true );

		n_x64_sync_base( hgui, n_posix_false );
		n_x64_sync_apps( hgui, n_posix_false );

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == N_X64_SYNC_TIMER_ID )
		{

			static int phase = 0;

			if ( phase == 0 )
			{
				phase = 1;
				n_win_hwndprintf_literal( hgui, "Done!" );
			} else
			if ( phase == 1 )
			{
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_exit( &hgui, 1 );

		n_win_timer_exit( hwnd, N_X64_SYNC_TIMER_ID );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		COLORREF fg = n_bmp_argb2colorref( n_win_dwm_windowcolor_arranged() );
		COLORREF bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE );

		int percent = 0;
		if ( n_x64_sync_count != 0 )
		{
			percent = (n_type_real) n_x64_sync_index / n_x64_sync_count * 100;
			if ( percent >= 100 )
			{
				if ( n_x64_sync_timer_onoff == n_posix_false )
				{
					n_x64_sync_timer_onoff = n_posix_true;
					SetTimer( hwnd, N_X64_SYNC_TIMER_ID, N_X64_SYNC_TIMER_MSEC, NULL );
				}
			}
		}

		n_win_progressbar_proc( hwnd,msg,wparam,lparam, hgui, EDGE_ETCHED, percent, fg,bg );
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

