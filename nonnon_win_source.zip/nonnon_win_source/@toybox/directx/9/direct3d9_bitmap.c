// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_d3d9_debug_literal( str ) n_posix_debug_literal( str )

// internal
void
n_d3d9_debug( n_posix_char *str )
{

	n_win_hwndprintf( n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow, str, 0 );


	return;
}

n_posix_bool
n_d3d9_bitmap_is_on( void )
{
	return ( ( n_d3d9_IDirect3DVertexBuffer9 != NULL )&&( n_d3d9_vertices != NULL ) );
}

void
n_d3d9_bitmap_flush( n_type_gfx sx, n_type_gfx sy, u32 color )
{

	if ( n_posix_false == n_d3d9_bitmap_is_on() ) { return; }


	n_type_gfx x = 0;
	n_type_gfx y = 0;

	while( 1 )
	{

		n_type_gfx i = x + ( y * sx );

		n_d3d9_vertices[ i ].x     = x;
		n_d3d9_vertices[ i ].y     = y;
		n_d3d9_vertices[ i ].color = color;


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_d3d9_bitmap_exit( void )
{

	if ( n_d3d9_IDirect3DVertexBuffer9 != NULL )
	{

		IDirect3DVertexBuffer9_Unlock ( n_d3d9_IDirect3DVertexBuffer9 );
		IDirect3DVertexBuffer9_Release( n_d3d9_IDirect3DVertexBuffer9 );

		n_d3d9_IDirect3DVertexBuffer9 = NULL;

	}


	return;
}

void
n_d3d9_bitmap_init( s32 sx, s32 sy )
{

	if ( n_d3d9_IDirect3DDevice9 == NULL )
	{
n_d3d9_debug_literal( "n_d3d9_IDirect3DDevice9 : NULL" );
		return;
	}


	n_d3d9_bitmap_exit();


	// [Needed] : this position is important

	n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth  = sx;
	n_d3d9_D3DPRESENT_PARAMETERS.BackBufferHeight = sy;

	hr = IDirect3DDevice9_Reset
	(
		 n_d3d9_IDirect3DDevice9,
		&n_d3d9_D3DPRESENT_PARAMETERS
	);


	int byte = ( sx * sy ) * sizeof( n_d3d9_vertex );

	hr = IDirect3DDevice9_CreateVertexBuffer
	(
		 n_d3d9_IDirect3DDevice9,
		 byte,
		 D3DUSAGE_DONOTCLIP,
		 N_D3D9_VERTEX,
		 D3DPOOL_DEFAULT,
		&n_d3d9_IDirect3DVertexBuffer9,
		 NULL
	);
	if ( FAILED( hr ) )
	{
n_d3d9_debug_literal( "IDirect3DDevice9_CreateVertexBuffer()" );

		return;
	}


	IDirect3DDevice9_SetRenderState
	(
		n_d3d9_IDirect3DDevice9,
		D3DRS_CLIPPING,
		FALSE
	);


	hr = IDirect3DVertexBuffer9_Lock
	(
		n_d3d9_IDirect3DVertexBuffer9,
		0,
		0,
		(void*) &n_d3d9_vertices,
		0
	);
	if ( FAILED( hr ) )
	{
n_d3d9_debug_literal( "IDirect3DVertexBuffer9_Lock()" );

		return;
	}


	IDirect3DDevice9_SetFVF
	(
		n_d3d9_IDirect3DDevice9,
		N_D3D9_VERTEX
	);

	hr = IDirect3DDevice9_SetStreamSource
	(
		n_d3d9_IDirect3DDevice9,
		0,
		n_d3d9_IDirect3DVertexBuffer9,
		0,
		sizeof( n_d3d9_vertex )
	);
	if ( FAILED( hr ) )
	{
n_d3d9_debug_literal( "IDirect3DDevice9_SetStreamSource()" );

		return;
	}


	return;
}

#define n_d3d9_bitmap_sync_all( bmp ) n_d3d9_bitmap_sync( bmp, 0,0,-1,-1 )

void
n_d3d9_bitmap_sync( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( n_d3d9_vertices == NULL ) { return; }

	if ( n_bmp_error( bmp ) ) { return; }


	// Clipping

	if ( sx < 0 ) { sx = N_BMP_SX( bmp ); }
	if ( sy < 0 ) { sy = N_BMP_SY( bmp ); }

	s32 fsx = n_posix_min_s32( N_BMP_SX( bmp ), sx );
	s32 fsy = n_posix_min_s32( N_BMP_SY( bmp ), sy );
	s32 fx  = x;
	s32 fy  = y;

	if ( fx < 0 ) { fsx += fx; fx = 0; }
	if ( fy < 0 ) { fsy += fy; fy = 0; }

	if ( fsx <= 0 ) { return; }
	if ( fsy <= 0 ) { return; }


	n_type_gfx tsx = n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth;
	n_type_gfx tsy = n_d3d9_D3DPRESENT_PARAMETERS.BackBufferHeight;
	n_type_gfx tx  = n_posix_min_n_type_gfx( tsx, fx + fsx );
	n_type_gfx ty  = n_posix_min_n_type_gfx( tsy, fy + fsy );

	if ( tsx <= 0 ) { return; }
	if ( tsy <= 0 ) { return; }


	n_type_gfx start_x = fx;
	while( 1 )
	{

		u32 color;
		n_bmp_ptr_get_fast( bmp, fx,fy, &color );


		int i = fx + ( fy * tsx );

		n_d3d9_vertices[ i ].x     = fx;
		n_d3d9_vertices[ i ].y     = fy;
		//n_d3d9_vertices[ i ].z     = 0.0;
		//n_d3d9_vertices[ i ].rhw   = 0.0;
		n_d3d9_vertices[ i ].color = color;


		fx++;
		if ( fx >= tx )
		{

			fx = start_x;

			fy++;
			if ( fy >= ty ) { break; }
		}
	}


	return;
}

void
n_d3d9_bitmap_copy( n_bmp *bmp_f, n_bmp *bmp_t, s32 fx, s32 fy, s32 fsx, s32 fsy, s32 tx, s32 ty )
{

	// [!] : "bmp_t" is dummy


	if ( n_d3d9_vertices == NULL ) { return; }


	if ( n_bmp_error_clipping( bmp_f,bmp_t, &fx,&fy,&fsx,&fsy, &tx,&ty ) ) { return; }


	n_type_int pos;
	u32        color;

	n_type_gfx start_fx = fx;
	n_type_gfx start_tx = tx;
	while( 1 )
	{

		n_bmp_ptr_get_fast( bmp_f, fx,fy, &color );

		pos = tx + ( ty * n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth );

		n_d3d9_vertices[ pos ].color = color;


		fx++; tx++;
		if ( fx >= fsx )
		{

			fx = start_fx;
			tx = start_tx;

			fy++; ty++;
			if ( fy >= fsy ) { break; }
		}
	}


	return;
}

void
n_d3d9_bitmap_scroll( n_bmp *bmp, s32 ox, s32 oy )
{

	// [!] : not used : "bmp"

	if ( n_d3d9_vertices == NULL ) { return; }


	n_type_gfx count = N_BMP_SX( bmp ) * N_BMP_SY( bmp );


	s32 i = 0;
	while( 1 )
	{

		n_d3d9_vertices[ i ].x += ox;
		n_d3d9_vertices[ i ].y += oy;

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

#define n_d3d9_bitmap_draw_all( bmp ) n_d3d9_bitmap_draw( bmp, 0,0,-1,-1 )

void
n_d3d9_bitmap_draw( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( n_d3d9_IDirect3DDevice9 == NULL ) { return; }


	hr = IDirect3DDevice9_BeginScene( n_d3d9_IDirect3DDevice9 );
	if ( FAILED( hr ) )
	{
n_d3d9_debug_literal( "IDirect3DDevice9_BeginScene()" );

		return;
	}


	// Clipping

	if ( sx < 0 ) { sx = N_BMP_SX( bmp ); }
	if ( sy < 0 ) { sy = N_BMP_SY( bmp ); }

	s32 fsx = n_posix_min_s32( N_BMP_SX( bmp ), sx );
	s32 fsy = n_posix_min_s32( N_BMP_SY( bmp ), sy );
	s32 fx  = x;
	s32 fy  = y;

	if ( fx < 0 ) { fsx += fx; fx = 0; }
	if ( fy < 0 ) { fsy += fy; fy = 0; }

	if ( fsx <= 0 ) { return; }
	if ( fsy <= 0 ) { return; }


	s32 tsx = n_d3d9_D3DPRESENT_PARAMETERS.BackBufferWidth;
	s32 tsy = n_d3d9_D3DPRESENT_PARAMETERS.BackBufferHeight;
	s32 tx  = n_posix_min_s32( tsx, fx + fsx );
	s32 ty  = n_posix_min_s32( tsy, fy + fsy );

	if ( tsx <= 0 ) { return; }
	if ( tsy <= 0 ) { return; }


	// [Needed] : anti-stretching

	RECT rect_redraw = { fx, fy, tx, ty };

	while( 1 )
	{

		hr = IDirect3DDevice9_DrawPrimitive
		(
			n_d3d9_IDirect3DDevice9,
			D3DPT_POINTLIST,
			fx + ( fy * tsx ),
			fsx
		);
		if ( FAILED( hr ) )
		{
n_d3d9_debug_literal( "IDirect3DDevice9_DrawPrimitive" );

			break;
		}


		fy++;
		if ( fy >= ty ) { break; }
	}


	IDirect3DDevice9_EndScene( n_d3d9_IDirect3DDevice9 );


	IDirect3DDevice9_Present
	(
		 n_d3d9_IDirect3DDevice9,
		&rect_redraw,
		&rect_redraw,
		 n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow,
		 NULL
	);


	return;
}

