// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#include "../../../nonnon/neutral/posix.c"
#include "../../../nonnon/win32/win.c"


#include <ole2.h>




#define IDirectDrawPalette int
#define IDirectDrawClipper int

#define PALETTEENTRY           int
#define DDENUMMODESCALLBACK    int
#define DDENUMSURFACESCALLBACK int
#define DDBLTFX                int
#define DDBLTBATCH             int
#define DDPIXELFORMAT          int
#define DDOVERLAYFX            int



#define DUMMYUNIONNAMEN( n ) u##n


#define DD_ROP_SPACE ( 8 )


#define DDSCAPS_RESERVED1          0x00000001
#define DDSCAPS_ALPHA              0x00000002
#define DDSCAPS_BACKBUFFER         0x00000004
#define DDSCAPS_COMPLEX            0x00000008
#define DDSCAPS_FLIP               0x00000010
#define DDSCAPS_FRONTBUFFER        0x00000020
#define DDSCAPS_OFFSCREENPLAIN     0x00000040
#define DDSCAPS_OVERLAY            0x00000080
#define DDSCAPS_PALETTE            0x00000100
#define DDSCAPS_PRIMARYSURFACE     0x00000200
#define DDSCAPS_RESERVED3          0x00000400
#define DDSCAPS_PRIMARYSURFACELEFT 0x00000000
#define DDSCAPS_SYSTEMMEMORY       0x00000800
#define DDSCAPS_TEXTURE            0x00001000
#define DDSCAPS_3DDEVICE           0x00002000
#define DDSCAPS_VIDEOMEMORY        0x00004000
#define DDSCAPS_VISIBLE            0x00008000
#define DDSCAPS_WRITEONLY          0x00010000
#define DDSCAPS_ZBUFFER            0x00020000
#define DDSCAPS_OWNDC              0x00040000
#define DDSCAPS_LIVEVIDEO          0x00080000
#define DDSCAPS_HWCODEC            0x00100000
#define DDSCAPS_MODEX              0x00200000
#define DDSCAPS_MIPMAP             0x00400000
#define DDSCAPS_RESERVED2          0x00800000
#define DDSCAPS_ALLOCONLOAD        0x04000000
#define DDSCAPS_VIDEOPORT          0x08000000
#define DDSCAPS_LOCALVIDMEM        0x10000000
#define DDSCAPS_NONLOCALVIDMEM     0x20000000
#define DDSCAPS_STANDARDVGAMODE    0x40000000
#define DDSCAPS_OPTIMIZED          0x80000000


#define DDSCL_FULLSCREEN         0x00000001
#define DDSCL_ALLOWREBOOT        0x00000002
#define DDSCL_NOWINDOWCHANGES    0x00000004
#define DDSCL_NORMAL             0x00000008
#define DDSCL_EXCLUSIVE          0x00000010
#define DDSCL_ALLOWMODEX         0x00000040
#define DDSCL_SETFOCUSWINDOW     0x00000080
#define DDSCL_SETDEVICEWINDOW    0x00000100
#define DDSCL_CREATEDEVICEWINDOW 0x00000200
#define DDSCL_MULTITHREADED      0x00000400
#define DDSCL_FPUSETUP           0x00000800
#define DDSCL_FPUPRESERVE        0x00001000

#define DDSD_CAPS                0x00000001
#define DDSD_HEIGHT              0x00000002
#define DDSD_WIDTH               0x00000004
#define DDSD_PITCH               0x00000008
#define DDSD_BACKBUFFERCOUNT     0x00000020
#define DDSD_ZBUFFERBITDEPTH     0x00000040
#define DDSD_ALPHABITDEPTH       0x00000080
#define DDSD_LPSURFACE           0x00000800
#define DDSD_PIXELFORMAT         0x00001000
#define DDSD_CKDESTOVERLAY       0x00002000
#define DDSD_CKDESTBLT           0x00004000
#define DDSD_CKSRCOVERLAY        0x00008000
#define DDSD_CKSRCBLT            0x00010000
#define DDSD_MIPMAPCOUNT         0x00020000
#define DDSD_REFRESHRATE         0x00040000
#define DDSD_LINEARSIZE          0x00080000
#define DDSD_TEXTURESTAGE        0x00100000
#define DDSD_FVF                 0x00200000
#define DDSD_SRCVBHANDLE         0x00400000
#define DDSD_DEPTH               0x00800000
#define DDSD_ALL                 0x00fff9ee


typedef struct _DDSCAPS
{

	DWORD dwCaps;

} DDSCAPS;

typedef struct _DDSCAPS2
{

	DWORD dwCaps;
	DWORD dwCaps2;
	DWORD dwCaps3;
	union
	{

		DWORD dwCaps4;
		DWORD dwVolumeDepth;

	} DUMMYUNIONNAMEN(1);

} DDSCAPS2;

typedef struct _DDCAPS
{

	DWORD    dwSize;
	DWORD    dwCaps;
	DWORD    dwCaps2;
	DWORD    dwCKeyCaps;
	DWORD    dwFXCaps;
	DWORD    dwFXAlphaCaps;
	DWORD    dwPalCaps;
	DWORD    dwSVCaps;
	DWORD    dwAlphaBltConstBitDepths;
	DWORD    dwAlphaBltPixelBitDepths;
	DWORD    dwAlphaBltSurfaceBitDepths;
	DWORD    dwAlphaOverlayConstBitDepths;
	DWORD    dwAlphaOverlayPixelBitDepths;
	DWORD    dwAlphaOverlaySurfaceBitDepths;
	DWORD    dwZBufferBitDepths;
	DWORD    dwVidMemTotal;
	DWORD    dwVidMemFree;
	DWORD    dwMaxVisibleOverlays;
	DWORD    dwCurrVisibleOverlays;
	DWORD    dwNumFourCCCodes;
	DWORD    dwAlignBoundarySrc;
	DWORD    dwAlignSizeSrc;
	DWORD    dwAlignBoundaryDest;
	DWORD    dwAlignSizeDest;
	DWORD    dwAlignStrideAlign;
	DWORD    dwRops[ DD_ROP_SPACE ];
	DDSCAPS  ddsOldCaps;
	DWORD    dwMinOverlayStretch;
	DWORD    dwMaxOverlayStretch;
	DWORD    dwMinLiveVideoStretch;
	DWORD    dwMaxLiveVideoStretch;
	DWORD    dwMinHwCodecStretch; 
	DWORD    dwMaxHwCodecStretch;
	DWORD    dwReserved1;
	DWORD    dwReserved2;
	DWORD    dwReserved3;
	DWORD    dwSVBCaps;
	DWORD    dwSVBCKeyCaps;
	DWORD    dwSVBFXCaps;
	DWORD    dwSVBRops[ DD_ROP_SPACE ];
	DWORD    dwVSBCaps;
	DWORD    dwVSBCKeyCaps;
	DWORD    dwVSBFXCaps;
	DWORD    dwVSBRops[ DD_ROP_SPACE ];
	DWORD    dwSSBCaps;
	DWORD    dwSSBCKeyCaps;
	DWORD    dwSSBFXCaps;
	DWORD    dwSSBRops[ DD_ROP_SPACE ];
	DWORD    dwMaxVideoPorts;
	DWORD    dwCurrVideoPorts;
	DWORD    dwSVBCaps2;
	DWORD    dwNLVBCaps;
	DWORD    dwNLVBCaps2;
	DWORD    dwNLVBCKeyCaps;
	DWORD    dwNLVBFXCaps;
	DWORD    dwNLVBRops[ DD_ROP_SPACE ];
	DDSCAPS2 ddsCaps;

} DDCAPS;

typedef struct _DDCOLORKEY
{

	DWORD dwColorSpaceLowValue;
	DWORD dwColorSpaceHighValue;

} DDCOLORKEY;

typedef struct _DDSURFACEDESC
{

	DWORD dwSize;
	DWORD dwFlags;
	DWORD dwHeight;
	DWORD dwWidth;
	union
	{
		LONG  lPitch;
		DWORD  dwLinearSize;
	} DUMMYUNIONNAMEN(1);
	DWORD dwBackBufferCount;
	union
	{
		DWORD dwMipMapCount;
		DWORD dwZBufferBitDepth;
		DWORD dwRefreshRate;
	} DUMMYUNIONNAMEN(2);
	DWORD         dwAlphaBitDepth;
	DWORD         dwReserved;
	LPVOID        lpSurface;
	DDCOLORKEY    ddckCKDestOverlay;
	DDCOLORKEY    ddckCKDestBlt;
	DDCOLORKEY    ddckCKSrcOverlay;
	DDCOLORKEY    ddckCKSrcBlt;
	DDPIXELFORMAT ddpfPixelFormat;
	DDSCAPS       ddsCaps;

} DDSURFACEDESC;

typedef struct _DDSURFACEDESC2
{

	DWORD dwSize;
	DWORD dwFlags;
	DWORD dwHeight;
	DWORD dwWidth;
	union
	{
		LONG  lPitch;
		DWORD dwLinearSize;
	} DUMMYUNIONNAMEN(1);
	union
	{
		DWORD dwBackBufferCount;
		DWORD dwDepth;
	} DUMMYUNIONNAMEN(5);
	union
	{
		DWORD dwMipMapCount;
		DWORD dwRefreshRate;
		DWORD dwSrcVBHandle;
	} DUMMYUNIONNAMEN(2);
	DWORD  dwAlphaBitDepth;
	DWORD  dwReserved;
	LPVOID lpSurface;
	union
	{
		DDCOLORKEY ddckCKDestOverlay;
		DWORD      dwEmptyFaceColor;
	} DUMMYUNIONNAMEN(3);
	DDCOLORKEY ddckCKDestBlt;
	DDCOLORKEY ddckCKSrcOverlay;
	DDCOLORKEY ddckCKSrcBlt;
	union
	{
		DDPIXELFORMAT ddpfPixelFormat;
		DWORD         dwFVF;
	} DUMMYUNIONNAMEN(4);
	DDSCAPS2 ddsCaps;
	DWORD    dwTextureStage;

} DDSURFACEDESC2;


const GUID IID_IDirectDrawSurface = { 0x6C14DB81,0xA733,0x11CE, { 0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60 } };

EXTERN_C const IID IID_IDirectDrawSurface;
#define INTERFACE IDirectDrawSurface
DECLARE_INTERFACE_( IDirectDrawSurface, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, VOID** ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( AddAttachedSurface    )( THIS_ IDirectDrawSurface* ) PURE;
	STDMETHOD( AddOverlayDirtyRect   )( THIS_ RECT* ) PURE;
	STDMETHOD( Blt                   )( THIS_ RECT*, IDirectDrawSurface*, RECT*, DWORD, DDBLTFX* ) PURE;
	STDMETHOD( BltBatch              )( THIS_ DDBLTBATCH*, DWORD, DWORD ) PURE;
	STDMETHOD( BltFast               )( THIS_ DWORD, DWORD, IDirectDrawSurface*, RECT*, DWORD ) PURE;
	STDMETHOD( DeleteAttachedSurface )( THIS_ DWORD, IDirectDrawSurface* ) PURE;
	STDMETHOD( EnumAttachedSurfaces  )( THIS_ VOID*, DDENUMSURFACESCALLBACK* ) PURE;
	STDMETHOD( EnumOverlayZOrders    )( THIS_ DWORD, VOID*, DDENUMSURFACESCALLBACK* ) PURE;
	STDMETHOD( Flip                  )( THIS_ IDirectDrawSurface*, DWORD ) PURE;
	STDMETHOD( GetAttachedSurface    )( THIS_ DDSCAPS*, IDirectDrawSurface* ) PURE;
	STDMETHOD( GetBltStatus          )( THIS_ DWORD ) PURE;
	STDMETHOD( GetCaps               )( THIS_ DDSCAPS* ) PURE;
	STDMETHOD( GetClipper            )( THIS_ IDirectDrawClipper* ) PURE;
	STDMETHOD( GetColorKey           )( THIS_ DWORD, DDCOLORKEY* ) PURE;
	STDMETHOD( GetDC                 )( THIS_ HDC* ) PURE;
	STDMETHOD( GetFlipStatus         )( THIS_ DWORD ) PURE;
	STDMETHOD( GetOverlayPosition    )( THIS_ LONG*, LONG* ) PURE;
	STDMETHOD( GetPalette            )( THIS_ IDirectDrawPalette* ) PURE;
	STDMETHOD( GetPixelFormat        )( THIS_ DDPIXELFORMAT* ) PURE;
	STDMETHOD( GetSurfaceDesc        )( THIS_ DDSURFACEDESC* ) PURE;
	STDMETHOD( Initialize            )( THIS_ void*, DDSURFACEDESC* ) PURE;
	STDMETHOD( IsLost                )( THIS ) PURE;
	STDMETHOD( Lock                  )( THIS_ RECT*, DDSURFACEDESC*, DWORD, HANDLE ) PURE;
	STDMETHOD( ReleaseDC             )( THIS_ HDC ) PURE;
	STDMETHOD( Restore               )( THIS ) PURE;
	STDMETHOD( SetClipper            )( THIS_ IDirectDrawClipper* ) PURE;
	STDMETHOD( SetColorKey           ) (THIS_ DWORD, DDCOLORKEY* ) PURE;
	STDMETHOD( SetOverlayPosition    )( THIS_ LONG, LONG ) PURE;
	STDMETHOD( SetPalette            )( THIS_ IDirectDrawPalette* ) PURE;
	STDMETHOD( Unlock                )( THIS_ VOID* ) PURE;
	STDMETHOD( UpdateOverlay         )( THIS_ RECT*, IDirectDrawSurface*, RECT*, DWORD, DDOVERLAYFX* ) PURE;
	STDMETHOD( UpdateOverlayDisplay  )( THIS_ DWORD ) PURE;
	STDMETHOD( UpdateOverlayZOrder   )( THIS_ DWORD, IDirectDrawSurface* ) PURE;
};
#undef INTERFACE

#define IDirectDrawSurface_QueryInterface(p,a,b)        (p)->lpVtbl->QueryInterface(p,a,b)
#define IDirectDrawSurface_AddRef(p)                    (p)->lpVtbl->AddRef(p)
#define IDirectDrawSurface_Release(p)                   (p)->lpVtbl->Release(p)
#define IDirectDrawSurface_AddAttachedSurface(p,a)      (p)->lpVtbl->AddAttachedSurface(p,a)
#define IDirectDrawSurface_AddOverlayDirtyRect(p,a)     (p)->lpVtbl->AddOverlayDirtyRect(p,a)
#define IDirectDrawSurface_Blt(p,a,b,c,d,e)             (p)->lpVtbl->Blt(p,a,b,c,d,e)
#define IDirectDrawSurface_BltBatch(p,a,b,c)            (p)->lpVtbl->BltBatch(p,a,b,c)
#define IDirectDrawSurface_BltFast(p,a,b,c,d,e)         (p)->lpVtbl->BltFast(p,a,b,c,d,e)
#define IDirectDrawSurface_DeleteAttachedSurface(p,a,b) (p)->lpVtbl->DeleteAttachedSurface(p,a,b)
#define IDirectDrawSurface_EnumAttachedSurfaces(p,a,b)  (p)->lpVtbl->EnumAttachedSurfaces(p,a,b)
#define IDirectDrawSurface_EnumOverlayZOrders(p,a,b,c)  (p)->lpVtbl->EnumOverlayZOrders(p,a,b,c)
#define IDirectDrawSurface_Flip(p,a,b)                  (p)->lpVtbl->Flip(p,a,b)
#define IDirectDrawSurface_GetAttachedSurface(p,a,b)    (p)->lpVtbl->GetAttachedSurface(p,a,b)
#define IDirectDrawSurface_GetBltStatus(p,a)            (p)->lpVtbl->GetBltStatus(p,a)
#define IDirectDrawSurface_GetCaps(p,b)                 (p)->lpVtbl->GetCaps(p,b)
#define IDirectDrawSurface_GetClipper(p,a)              (p)->lpVtbl->GetClipper(p,a)
#define IDirectDrawSurface_GetColorKey(p,a,b)           (p)->lpVtbl->GetColorKey(p,a,b)
#define IDirectDrawSurface_GetDC(p,a)                   (p)->lpVtbl->GetDC(p,a)
#define IDirectDrawSurface_GetFlipStatus(p,a)           (p)->lpVtbl->GetFlipStatus(p,a)
#define IDirectDrawSurface_GetOverlayPosition(p,a,b)    (p)->lpVtbl->GetOverlayPosition(p,a,b)
#define IDirectDrawSurface_GetPalette(p,a)              (p)->lpVtbl->GetPalette(p,a)
#define IDirectDrawSurface_GetPixelFormat(p,a)          (p)->lpVtbl->GetPixelFormat(p,a)
#define IDirectDrawSurface_GetSurfaceDesc(p,a)          (p)->lpVtbl->GetSurfaceDesc(p,a)
#define IDirectDrawSurface_Initialize(p,a,b)            (p)->lpVtbl->Initialize(p,a,b)
#define IDirectDrawSurface_IsLost(p)                    (p)->lpVtbl->IsLost(p)
#define IDirectDrawSurface_Lock(p,a,b,c,d)              (p)->lpVtbl->Lock(p,a,b,c,d)
#define IDirectDrawSurface_ReleaseDC(p,a)               (p)->lpVtbl->ReleaseDC(p,a)
#define IDirectDrawSurface_Restore(p)                   (p)->lpVtbl->Restore(p)
#define IDirectDrawSurface_SetClipper(p,a)              (p)->lpVtbl->SetClipper(p,a)
#define IDirectDrawSurface_SetColorKey(p,a,b)           (p)->lpVtbl->SetColorKey(p,a,b)
#define IDirectDrawSurface_SetOverlayPosition(p,a,b)    (p)->lpVtbl->SetOverlayPosition(p,a,b)
#define IDirectDrawSurface_SetPalette(p,a)              (p)->lpVtbl->SetPalette(p,a)
#define IDirectDrawSurface_Unlock(p,b)                  (p)->lpVtbl->Unlock(p,b)
#define IDirectDrawSurface_UpdateOverlay(p,a,b,c,d,e)   (p)->lpVtbl->UpdateOverlay(p,a,b,c,d,e)
#define IDirectDrawSurface_UpdateOverlayDisplay(p,a)    (p)->lpVtbl->UpdateOverlayDisplay(p,a)
#define IDirectDrawSurface_UpdateOverlayZOrder(p,a,b)   (p)->lpVtbl->UpdateOverlayZOrder(p,a,b)


const GUID CLSID_DirectDraw = { 0xD7B70EE0,0x4340,0x11CF, { 0xB0,0x63,0x00,0x20,0xAF,0xC2,0xCD,0x35 } };
const GUID  IID_IDirectDraw = { 0x6C14DB80,0xA733,0x11CE, { 0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60 } };

EXTERN_C const IID IID_IDirectDraw;
#define INTERFACE IDirectDraw
DECLARE_INTERFACE_( IDirectDraw, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, VOID** ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( Compact                )( THIS ) PURE;
	STDMETHOD( CreateClipper          )( THIS_ DWORD, IDirectDrawClipper**, IUnknown** ) PURE;
	STDMETHOD( CreatePalette          )( THIS_ DWORD, PALETTEENTRY*, IDirectDrawPalette**, IUnknown** ) PURE;
	STDMETHOD( CreateSurface          )( THIS_ DDSURFACEDESC*, IDirectDrawSurface**, IUnknown** ) PURE;
	STDMETHOD( DuplicateSurface       )( THIS_ IDirectDrawSurface*, IDirectDrawSurface** ) PURE;
	STDMETHOD( EnumDisplayModes       )( THIS_ DWORD, DDSURFACEDESC*, VOID*, DDENUMMODESCALLBACK* ) PURE;
	STDMETHOD( EnumSurfaces           )( THIS_ DWORD, DDSURFACEDESC*, VOID*, DDENUMSURFACESCALLBACK* ) PURE;
	STDMETHOD( FlipToGDISurface       )( THIS ) PURE;
	STDMETHOD( GetCaps                )( THIS_ DDCAPS*, DDCAPS* ) PURE;
	STDMETHOD( GetDisplayMode         )( THIS_ DDSURFACEDESC* ) PURE;
	STDMETHOD( GetFourCCCodes         )( THIS_ DWORD*, DWORD* ) PURE;
	STDMETHOD( GetGDISurface          )( THIS_ IDirectDrawSurface** ) PURE;
	STDMETHOD( GetMonitorFrequency    )( THIS_ DWORD* ) PURE;
	STDMETHOD( GetScanLine            )( THIS_ DWORD* ) PURE;
	STDMETHOD( GetVerticalBlankStatus )( THIS_ BOOL* ) PURE;
	STDMETHOD( Initialize             )( THIS_ GUID* ) PURE;
	STDMETHOD( RestoreDisplayMode     )( THIS ) PURE;
	STDMETHOD( SetCooperativeLevel    )( THIS_ HWND, DWORD ) PURE;
	STDMETHOD( SetDisplayMode         )( THIS_ DWORD, DWORD,DWORD ) PURE;
	STDMETHOD( WaitForVerticalBlank   )( THIS_ DWORD, HANDLE ) PURE;
};
#undef INTERFACE

#define IDirectDraw_QueryInterface(p, a, b)         (p)->lpVtbl->QueryInterface(p, a, b)
#define IDirectDraw_AddRef(p)                       (p)->lpVtbl->AddRef(p)
#define IDirectDraw_Release(p)                      (p)->lpVtbl->Release(p)
#define IDirectDraw_Compact(p)                      (p)->lpVtbl->Compact(p)
#define IDirectDraw_CreateClipper(p, a, b, c)       (p)->lpVtbl->CreateClipper(p, a, b, c)
#define IDirectDraw_CreatePalette(p, a, b, c, d)    (p)->lpVtbl->CreatePalette(p, a, b, c, d)
#define IDirectDraw_CreateSurface(p, a, b, c)       (p)->lpVtbl->CreateSurface(p, a, b, c)
#define IDirectDraw_DuplicateSurface(p, a, b)       (p)->lpVtbl->DuplicateSurface(p, a, b)
#define IDirectDraw_EnumDisplayModes(p, a, b, c, d) (p)->lpVtbl->EnumDisplayModes(p, a, b, c, d)
#define IDirectDraw_EnumSurfaces(p, a, b, c, d)     (p)->lpVtbl->EnumSurfaces(p, a, b, c, d)
#define IDirectDraw_FlipToGDISurface(p)             (p)->lpVtbl->FlipToGDISurface(p)
#define IDirectDraw_GetCaps(p, a, b)                (p)->lpVtbl->GetCaps(p, a, b)
#define IDirectDraw_GetDisplayMode(p, a)            (p)->lpVtbl->GetDisplayMode(p, a)
#define IDirectDraw_GetFourCCCodes(p, a, b)         (p)->lpVtbl->GetFourCCCodes(p, a, b)
#define IDirectDraw_GetGDISurface(p, a)             (p)->lpVtbl->GetGDISurface(p, a)
#define IDirectDraw_GetMonitorFrequency(p, a)       (p)->lpVtbl->GetMonitorFrequency(p, a)
#define IDirectDraw_GetScanLine(p, a)               (p)->lpVtbl->GetScanLine(p, a)
#define IDirectDraw_GetVerticalBlankStatus(p, a)    (p)->lpVtbl->GetVerticalBlankStatus(p, a)
#define IDirectDraw_Initialize(p, a)                (p)->lpVtbl->Initialize(p, a)
#define IDirectDraw_RestoreDisplayMode(p)           (p)->lpVtbl->RestoreDisplayMode(p)
#define IDirectDraw_SetCooperativeLevel(p, a, b)    (p)->lpVtbl->SetCooperativeLevel(p, a, b)
#define IDirectDraw_SetDisplayMode(p, a, b, c)      (p)->lpVtbl->SetDisplayMode(p, a, b, c)
#define IDirectDraw_WaitForVerticalBlank(p, a, b)   (p)->lpVtbl->WaitForVerticalBlank(p, a, b)




typedef struct {

	HMODULE             hmod;
	FARPROC             DirectDrawCreate;

	IDirectDraw        *IDirectDraw;
	IDirectDrawSurface *IDirectDrawSurface;

} n_directdraw;




#define n_directdraw_zero( p ) n_memory_zero( p, sizeof( n_directdraw ) )

bool
n_directdraw_exit( n_directdraw *p )
{

	if ( p == NULL ) { return true; }


	if ( p->IDirectDrawSurface != NULL ) { IDirectDrawSurface_Release( p->IDirectDrawSurface ); }
	if ( p->IDirectDraw        != NULL ) { IDirectDraw_Release       ( p->IDirectDraw        ); }


	if ( p->hmod != NULL ) { FreeLibrary( p->hmod ); }


	n_directdraw_zero( p );


	return false;
}

bool
n_directdraw_init( n_directdraw *p, HWND hwnd )
{

	if ( p == NULL ) { return true; }


	p->hmod = LoadLibrary( n_posix_literal( "Ddraw.dll" ) );
	if ( p->hmod == NULL )
	{
n_posix_debug_literal( " LoadLibrary() " );

		return true;
	}


	p->DirectDrawCreate = GetProcAddress( p->hmod, "DirectDrawCreate" );
	if ( p->DirectDrawCreate == NULL )
	{
n_posix_debug_literal( " GetProcAddress() " );

		n_directdraw_exit( p );

		return true;
	}


	HRESULT hret = p->DirectDrawCreate( NULL, &p->IDirectDraw, NULL );
	if ( ( FAILED( hret ) )||( p->IDirectDraw == NULL ) )
	{
n_posix_debug_literal( " IDirectDraw " );

		n_directdraw_exit( p );

		return true;
	}

	hret = IDirectDraw_SetCooperativeLevel( p->IDirectDraw, hwnd, DDSCL_NORMAL );
	if ( FAILED( hret ) )
	{
n_posix_debug_literal( " IDirectDraw_SetCooperativeLevel() : %d %08x ", hret, hret );

		n_directdraw_exit( p );

		return true;
	}

/*
	// [x] : E_NOTIMPL (0x80004001) is returned

	hret = IDirectDraw_SetDisplayMode( p->IDirectDraw, 640,480, 8 );
	if ( FAILED( hret ) )
	{
n_posix_debug_literal( " IDirectDraw_SetDisplayMode() : %d %08x ", hret, hret );

		n_directdraw_exit( p );

		return true;
	}
*/

	DDSURFACEDESC ddsd; ZeroMemory( &ddsd, sizeof( DDSURFACEDESC ) );

	ddsd.dwSize            = sizeof( DDSURFACEDESC );
	ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount = 1;

	// [x] : E_INVALIDARG (0x80070057) is returned

	hret = IDirectDraw_CreateSurface( p->IDirectDraw, &ddsd, &p->IDirectDrawSurface, NULL );
	if ( p->IDirectDrawSurface == NULL )
	{
n_posix_debug_literal( " IDirectDrawSurface : %d %08x ", hret, hret );

		return true;
	}


	return false;
}




void
n_ddraw_load( HWND hwnd, n_posix_char *cmdline )
{



	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char cmdline[ N_PATH_MAX ];

	static n_directdraw dd;

	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Nonnon DirectDraw Test", "", "" );
		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

		ShowWindow( hwnd, SW_NORMAL );

		n_directdraw_zero( &dd );
		n_directdraw_init( &dd, hwnd );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_ddraw_load( hwnd, cmdline );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_directdraw_exit( &dd );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

