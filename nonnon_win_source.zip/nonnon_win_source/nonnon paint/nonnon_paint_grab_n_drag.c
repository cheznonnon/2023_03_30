// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_paint_grab_n_drag_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MBUTTONDOWN :

		if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		n_win_cursor_add_literal( NULL, "NONNON_PAINT_PAW_ON" );

		SetCapture( hwnd );


		n_win_grab_n_drag_zero( &n_paint_grab_n_drag );
		n_win_grab_n_drag_init( &n_paint_grab_n_drag, hwnd );

	break;

	case WM_MOUSEMOVE :
	{

		if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		int dx,dy;
		if ( n_win_grab_n_drag_loop( &n_paint_grab_n_drag, &dx, &dy ) ) { break; }

		nwin_main.scrollx += dx;
		nwin_main.scrolly += dy;

		extern void n_paint_refresh_calc( void );
		n_paint_refresh_calc();

		n_paint_hscr.unit_pos = nwin_main.scrollx;
		n_paint_vscr.unit_pos = nwin_main.scrolly;

		n_win_scrollbar_draw_always( &n_paint_hscr, n_true );
		n_win_scrollbar_draw_always( &n_paint_vscr, n_true );

		n_paint_refresh_scroll();

	}
	break;


	case WM_MBUTTONUP :

		//if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		ReleaseCapture();

		n_paint_pen_cursor_default( NULL );

		n_win_grab_n_drag_exit( &n_paint_grab_n_drag );

	break;


	} // switch


	return;
}

