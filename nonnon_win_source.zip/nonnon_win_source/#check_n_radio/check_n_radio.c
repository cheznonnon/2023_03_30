// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_radiobutton.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_check check;
	static n_win_radio radio;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_check_zero( &check );
		n_win_check_init( &check, hwnd, n_posix_literal( "Check" ), 1 );

		n_win_radio_zero( &radio );
		n_win_radio_init( &radio, hwnd, n_posix_literal( "Radio" ), 1 );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

//n_win_check_onoff( &check, n_false );


		// [!] : for alignment check

		n_win_style_add( check.hwnd, WS_BORDER );
		n_win_style_add( radio.hwnd, WS_BORDER );


		// Size

		{

			n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

			s32 ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );

			s32 center_y = ( 200 / 2 );
			s32 offset_y = ( ( center_y - ctl ) / 2 );
			n_win_move( check.hwnd, ( 200 - 100 ) / 2,            offset_y, 100, ctl, n_true );
			n_win_move( radio.hwnd, ( 200 - 100 ) / 2, center_y + offset_y, 100, ctl, n_true );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{
			n_win_check_onoff( &check, n_false );
			n_win_radio_onoff( &radio, n_false );
		} else
		if ( wparam == VK_F2 )
		{
			n_posix_debug_literal
			(
				" Check %d : Radio %d ",
				n_win_check_is_checked( &check ),
				n_win_radio_is_checked( &radio )
			);
		} else
		if ( wparam == VK_F3 )
		{
			n_win_check_check( &check );
			n_win_radio_check( &radio );
		} else
		if ( wparam == VK_F4 )
		{
			n_win_check_uncheck( &check );
			n_win_radio_uncheck( &radio );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_check_exit( &check );
		n_win_radio_exit( &radio );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_check_proc( hwnd, msg, wparam, lparam, &check );
	n_win_radio_proc( hwnd, msg, wparam, lparam, &radio );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


