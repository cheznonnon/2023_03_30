// nfloppy
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../nonnon/project/define_unicode.c"




// the base layer

#include "../nonnon/neutral/txt.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"




#define N_FLOPPY_NAME_DEFAULT n_posix_literal( "name.txt" )




n_bool
n_floppy_main( const n_posix_char *cmdline )
{

	if ( n_string_is_empty( cmdline ) ) { return n_true; }

	if ( n_false == n_posix_stat_is_exist( cmdline ) ) { return n_true; }


	// [x] : VC++ 2017 : you cannot make a 1 MB fixed array

	const n_type_int  size_buffer = 1024 * 1024;
	      u8         *data        = n_memory_new( 1024 * 1024 );


	n_txt txt; n_txt_zero( &txt );


	n_string_path_folder_change( cmdline );


	n_type_int fsize = n_posix_stat_size( cmdline );
	if ( fsize <= size_buffer )
	{

		// Undivide


		// [!] : restore original filename

		n_posix_char *name;

		if ( n_txt_load( &txt, cmdline ) )
		{
			name = n_string_path_tmpname_new( txt.line[ 0 ] );
		} else {
			name = n_string_path_carboncopy ( txt.line[ 0 ] );
		}
//n_posix_debug( name );


		// [!] : for safety

		n_string_path_name( name, name );
		n_string_safename( name, name );


		n_posix_char *rel = n_string_path_relative_new( name );
		n_string_path_free( name );
		name = rel;
//n_posix_debug( name );

		if ( n_false == n_posix_stat_is_exist( n_posix_literal( "0" ) ) )
		{
			n_string_path_free( name );
			n_memory_free( data );

			return n_true;
		}

		FILE *fp_i = n_posix_fopen_write( name );
		if ( fp_i == NULL ) { n_string_path_free( name ); n_memory_free( data ); return n_true; }

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, i );
//n_posix_debug( str );

			if ( n_false == n_posix_stat_is_exist( str ) ) { break; }


			FILE *fp_o = n_posix_fopen_read( str );
			if ( fp_o == NULL ) { break; }

			fsize = n_posix_stat_size( str );

			n_posix_fread ( data, fsize, 1, fp_o );
			n_posix_fwrite( data, fsize, 1, fp_i );

			n_posix_fclose( fp_o );


			i++;

		}

		n_posix_fclose( fp_i );


		n_string_path_free( name );


	} else {


		FILE *fp_i = n_posix_fopen_read( cmdline );
		if ( fp_i == NULL ) { n_memory_free( data ); return n_true; }

		n_type_int size = 0;
		n_type_int i    = 0;
		n_posix_loop
		{

			n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, i );
//n_posix_debug( str );


			FILE *fp_o = n_posix_fopen_write( str );
			if ( fp_o == NULL ) { n_posix_fclose( fp_i ); n_memory_free( data ); return n_true; }

			n_posix_fread ( data, size_buffer, 1, fp_i );
			n_posix_fwrite( data, size_buffer, 1, fp_o );

			n_posix_fclose( fp_o );


			size += size_buffer;

			// [!] : check the next's next

			if ( fsize < ( size + size_buffer ) ) { break; }

			i++;

		}


		// [!] : output under 1MB

		if ( fsize != size )
		{

			i++;

			n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, i );


			FILE *fp_o = n_posix_fopen_write( str );
			if ( fp_o == NULL ) { n_posix_fclose( fp_i ); n_memory_free( data ); return n_true; }

			n_posix_fread ( data, fsize - size, 1, fp_i );
			n_posix_fwrite( data, fsize - size, 1, fp_o );

			n_posix_fclose( fp_o );

		}

		n_posix_fclose( fp_i );


		// [!] : save the original filename

		n_txt_new( &txt );

		n_txt_add( &txt, 0, cmdline );

		n_txt_save( &txt, N_FLOPPY_NAME_DEFAULT );

	}


	n_memory_free( data );


	n_txt_free( &txt );


	n_explorer_refresh( n_false );


	return n_false;
}

/*

int
main( void )
{

	n_posix_char *cmdline = n_win_commandline_new();

	n_bool ret = n_floppy_main( cmdline );

	n_string_path_free( cmdline );


	return ret;

}

*/

