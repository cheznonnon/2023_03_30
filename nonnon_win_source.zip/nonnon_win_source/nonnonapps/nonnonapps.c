// Nonnon Apps
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"

#include "../nonnon/com/IShellLink.c"

#include "../nonnon/win32/ole/IDropTarget.c"


// [!] : gdi.c needs IPicture.c and jpg.c

#include "../nonnon/win32/ole/IPicture.c"


#include "../nonnon/neutral/jpg.c"

#include "../nonnon/win32/gdi.c"


// [!] : there is a dependency

#define N_GAME_WAKE
#define N_GAME_NO_WINMAIN
#include "../nonnon/game/game.c"

#include "../nonnon/win32/win_scrollbar.c"


#include "../nonnon/win32/explorer.c"
//#include "../nonnon/win32/win.c"


// [!] : there is a dependency

#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"


#include "../nonnon/project/macro.c"




#define NONNON_APPS




// [!] : Shared

void
n_apps_taskbar( const n_posix_char *name )
{

	// [x] : Vista or earlier compatible behavior will be used if this code is used

	// [!] : Explorer can handle, OrangeCat cannot handle
	//
	//	using n_apps_register() is stable, see below

	return;


	HMODULE hmod = LoadLibrary( n_posix_literal( "shell32.dll" ) );
	if ( hmod == NULL ) { return; }

	FARPROC func = GetProcAddress( hmod, "SetCurrentProcessExplicitAppUserModelID" );
	if ( func != NULL )
	{

#ifdef UNICODE

		wchar_t *wstr = n_string_carboncopy( name );

#else // #ifndef UNICODE

		wchar_t *wstr = n_posix_ansi2unicode( name );

#endif // #ifndef UNICODE

		func( wstr );

		n_memory_free( wstr );

	}

	FreeLibrary( hmod );


	return;
}

void
n_apps_register( void )
{

	if ( n_false == n_sysinfo_version_7_or_later() ) { return; }


	// [!] : this code seems to be stable

	HKEY hive = HKEY_CURRENT_USER;

#ifdef _MSC_VER
	const n_posix_char *keyname = n_posix_literal( "Software\\Classes\\Applications\\NonnonApps.exe" );
#else  // #ifdef _MSC_VER
	const n_posix_char *keyname = n_posix_literal( "Software\\Classes\\Applications\\nonnonapps.exe" );
#endif // #ifdef _MSC_VER

	const n_posix_char *lval = n_posix_literal( "IsHostApp" );


	if ( n_false == n_registry_is_exist( hive, keyname, lval ) )
	{
		n_registry_write( hive, keyname, lval, REG_SZ, NULL, 0 );
	}


	return;
}

#define N_APPS_NAME_BATCHDROP      n_posix_literal( "Batch Drop" )
#define N_APPS_NAME_CALENDAR       n_posix_literal( "Calendar" )
#define N_APPS_NAME_CATPAD         n_posix_literal( "CatPad" )
#define N_APPS_NAME_CHARMAP        n_posix_literal( "Character Map" )
#define N_APPS_NAME_FELIS          n_posix_literal( "Felis" )
#define N_APPS_NAME_FTP            n_posix_literal( "FTP" )
#define N_APPS_NAME_MARIE          n_posix_literal( "Marie" )
#define N_APPS_NAME_NEKO_NO_TE     n_posix_literal( "Neko no Te" )
#define N_APPS_NAME_NMEMO          n_posix_literal( "nmemo" )
#define N_APPS_NAME_NMIDI          n_posix_literal( "nmidi" )
#define N_APPS_NAME_NMIXER         n_posix_literal( "Mixer" )
#define N_APPS_NAME_NONNON_PAINT   n_posix_literal( "Nonnon Paint" )
#define N_APPS_NAME_NTYPING        n_posix_literal( "Typing" )
#define N_APPS_NAME_NYAURISM       n_posix_literal( "Nyaurism" )
#define N_APPS_NAME_N_ATTRIB       n_posix_literal( "Attrib GUI" )
#define N_APPS_NAME_ORANGECAT      n_posix_literal( "OrangeCat" )
#define N_APPS_NAME_PROJECTCHECKER n_posix_literal( "Project Checker" )
#define N_APPS_NAME_PENTRAINER     n_posix_literal( "Pen Trainer" )
#define N_APPS_NAME_SLEEPY         n_posix_literal( "Sleepy" )
#define N_APPS_NAME_WATCHCAT       n_posix_literal( "Watchcat" )
#define N_APPS_NAME_WHEEL_AXL      n_posix_literal( "Wheel Axl" )
#define N_APPS_NAME_WHITENOISE     n_posix_literal( "White Noise" )
#define N_APPS_NAME_PINKNOISE      n_posix_literal( "Pink Noise" )

#define N_APPS_OPTION_CALENDAR       n_posix_literal( "-calendar" )
#define N_APPS_OPTION_CATPAD         n_posix_literal( "-catpad" )
#define N_APPS_OPTION_CHARMAP        n_posix_literal( "-charmap" )
#define N_APPS_OPTION_FELIS          n_posix_literal( "-felis" )
#define N_APPS_OPTION_FTP            n_posix_literal( "-ftp" )
#define N_APPS_OPTION_MARIE          n_posix_literal( "-marie" )
#define N_APPS_OPTION_NEKO_NO_TE     n_posix_literal( "-neko_no_te" )
#define N_APPS_OPTION_NMEMO          n_posix_literal( "-nmemo" )
#define N_APPS_OPTION_NMIDI          n_posix_literal( "-nmidi" )
#define N_APPS_OPTION_NMIXER         n_posix_literal( "-nmixer" )
#define N_APPS_OPTION_NONNON_PAINT   n_posix_literal( "-nonnon_paint" )
#define N_APPS_OPTION_NTYPING        n_posix_literal( "-ntyping" )
#define N_APPS_OPTION_NYAURISM       n_posix_literal( "-nyaurism" )
#define N_APPS_OPTION_N_ATTRIB       n_posix_literal( "-n_attrib" )
#define N_APPS_OPTION_ORANGECAT      n_posix_literal( "-orangecat" )
#define N_APPS_OPTION_PROJECTCHECKER n_posix_literal( "-projectchecker" )
#define N_APPS_OPTION_PENTRAINER     n_posix_literal( "-pentrainer" )
#define N_APPS_OPTION_SLEEPY         n_posix_literal( "-sleepy" )
#define N_APPS_OPTION_WATCHCAT       n_posix_literal( "-watchcat" )
#define N_APPS_OPTION_WHEEL_AXL      n_posix_literal( "-wheel_axl" )
#define N_APPS_OPTION_WHITENOISE     n_posix_literal( "-whitenoise" )
#define N_APPS_OPTION_PINKNOISE      n_posix_literal( "-pinknoise" )
#define N_APPS_OPTION_NONNON         n_posix_literal( "-nonnon_special" )

#define N_APPS_ICON_OFFSET_CALENDAR       ( 0 + 1 )
#define N_APPS_ICON_OFFSET_CATPAD         ( 0 + 1 + 1 )
#define N_APPS_ICON_OFFSET_CHARMAP        ( 0 )
#define N_APPS_ICON_OFFSET_FELIS          ( 0 + 1 + 1 + 8 )
#define N_APPS_ICON_OFFSET_FTP            ( 0 + 1 + 1 + 8 + 9 )
#define N_APPS_ICON_OFFSET_MARIE          ( 0 + 1 + 1 + 8 + 9 + 1 )
#define N_APPS_ICON_OFFSET_NEKO_NO_TE     ( 0 + 1 + 1 + 8 + 9 + 1 + 8 )
#define N_APPS_ICON_OFFSET_NMEMO          ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 )
#define N_APPS_ICON_OFFSET_NMIDI          ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 )
#define N_APPS_ICON_OFFSET_NMIXER         ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 )
#define N_APPS_ICON_OFFSET_NONNON_PAINT   ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 )
#define N_APPS_ICON_OFFSET_NTYPING        ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 )
#define N_APPS_ICON_OFFSET_NYAURISM       ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 )
#define N_APPS_ICON_OFFSET_N_ATTRIB       ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 )
#define N_APPS_ICON_OFFSET_ORANGECAT      ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 )
#define N_APPS_ICON_OFFSET_PROJECTCHECKER ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 + 1 )
#define N_APPS_ICON_OFFSET_PENTRAINER     ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 + 1 + 2 )
#define N_APPS_ICON_OFFSET_SLEEPY         ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 + 1 + 2 + 5 )
#define N_APPS_ICON_OFFSET_WATCHCAT       ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 + 1 + 2 + 5 )
#define N_APPS_ICON_OFFSET_WHEEL_AXL      ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23 + 1 + 8 + 1 + 1 + 2 + 5 + 5 )
#define N_APPS_ICON_OFFSET_WHITENOISE     ( 0 + 1 + 1 + 8 + 9 + 1 + 8 + 2 + 1 + 5 + 2 + 23  + 1+ 8 + 1 + 1 + 2 + 5 + 5 + 2 )
#define N_APPS_ICON_OFFSET_PINKNOISE      N_APPS_ICON_OFFSET_WHITENOISE

#define n_apps_shortcut_calendar()       n_project_shortcut( N_APPS_NAME_CALENDAR,       N_APPS_OPTION_CALENDAR,       N_APPS_ICON_OFFSET_CALENDAR       )
#define n_apps_shortcut_catpad()         n_project_shortcut( N_APPS_NAME_CATPAD,         N_APPS_OPTION_CATPAD,         N_APPS_ICON_OFFSET_CATPAD         )
#define n_apps_shortcut_charmap()        n_project_shortcut( N_APPS_NAME_CHARMAP,        N_APPS_OPTION_CHARMAP,        N_APPS_ICON_OFFSET_CHARMAP        )
#define n_apps_shortcut_felis()          n_project_shortcut( N_APPS_NAME_FELIS,          N_APPS_OPTION_FELIS,          N_APPS_ICON_OFFSET_FELIS          )
#define n_apps_shortcut_ftp()            n_project_shortcut( N_APPS_NAME_FTP,            N_APPS_OPTION_FTP,            N_APPS_ICON_OFFSET_FTP            )
#define n_apps_shortcut_marie()          n_project_shortcut( N_APPS_NAME_MARIE,          N_APPS_OPTION_MARIE,          N_APPS_ICON_OFFSET_MARIE          )
#define n_apps_shortcut_mixer()          n_project_shortcut( N_APPS_NAME_NMIXER,         N_APPS_OPTION_NMIXER,         N_APPS_ICON_OFFSET_NMIXER         )
#define n_apps_shortcut_neko_no_te()     n_project_shortcut( N_APPS_NAME_NEKO_NO_TE,     N_APPS_OPTION_NEKO_NO_TE,     N_APPS_ICON_OFFSET_NEKO_NO_TE     )
#define n_apps_shortcut_nmemo()          n_project_shortcut( N_APPS_NAME_NMEMO,          N_APPS_OPTION_NMEMO,          N_APPS_ICON_OFFSET_NMEMO          )
#define n_apps_shortcut_nmidi()          n_project_shortcut( N_APPS_NAME_NMIDI,          N_APPS_OPTION_NMIDI,          N_APPS_ICON_OFFSET_NMIDI          )
#define n_apps_shortcut_nonnon_paint()   n_project_shortcut( N_APPS_NAME_NONNON_PAINT,   N_APPS_OPTION_NONNON_PAINT,   N_APPS_ICON_OFFSET_NONNON_PAINT   )
#define n_apps_shortcut_ntyping()        n_project_shortcut( N_APPS_NAME_NTYPING,        N_APPS_OPTION_NTYPING,        N_APPS_ICON_OFFSET_NTYPING        )
#define n_apps_shortcut_nyaurism()       n_project_shortcut( N_APPS_NAME_NYAURISM,       N_APPS_OPTION_NYAURISM,       N_APPS_ICON_OFFSET_NYAURISM       )
#define n_apps_shortcut_n_attrib()       n_project_shortcut( N_APPS_NAME_N_ATTRIB,       N_APPS_OPTION_N_ATTRIB,       N_APPS_ICON_OFFSET_N_ATTRIB       )
#define n_apps_shortcut_orangecat()      n_project_shortcut( N_APPS_NAME_ORANGECAT,      N_APPS_OPTION_ORANGECAT,      N_APPS_ICON_OFFSET_ORANGECAT      )
#define n_apps_shortcut_projectchecker() n_project_shortcut( N_APPS_NAME_PROJECTCHECKER, N_APPS_OPTION_PROJECTCHECKER, N_APPS_ICON_OFFSET_PROJECTCHECKER )
#define n_apps_shortcut_pentrainer()     n_project_shortcut( N_APPS_NAME_PENTRAINER,     N_APPS_OPTION_PENTRAINER,     N_APPS_ICON_OFFSET_PENTRAINER     )
#define n_apps_shortcut_sleepy()         n_project_shortcut( N_APPS_NAME_SLEEPY,         N_APPS_OPTION_SLEEPY,         N_APPS_ICON_OFFSET_SLEEPY         )
#define n_apps_shortcut_watchcat()       n_project_shortcut( N_APPS_NAME_WATCHCAT,       N_APPS_OPTION_WATCHCAT,       N_APPS_ICON_OFFSET_WATCHCAT       )
#define n_apps_shortcut_wheel_axl()      n_project_shortcut( N_APPS_NAME_WHEEL_AXL,      N_APPS_OPTION_WHEEL_AXL,      N_APPS_ICON_OFFSET_WHEEL_AXL      )
#define n_apps_shortcut_whitenoise()     n_project_shortcut( N_APPS_NAME_WHITENOISE,     N_APPS_OPTION_WHITENOISE,     N_APPS_ICON_OFFSET_WHITENOISE     )
#define n_apps_shortcut_pinknoise()      n_project_shortcut( N_APPS_NAME_PINKNOISE,      N_APPS_OPTION_PINKNOISE,      N_APPS_ICON_OFFSET_PINKNOISE      )



// Components

#include "./bat.c"

#include "./favorites2html.c"
#include "./floppy.c"
#include "./ftp.c"
#include "./pinknoise.c"
#include "./whitenoise.c"

#include "../calendar/calendar.c"
#include "../catpad/catpad.c"
#include "../charactermap/charactermap.c"
#include "../felis/felis.c"
#include "../marie/marie.c"
#include "../n_attrib/n_attrib.c"
#include "../neko_no_te/neko_no_te.c"
#include "../nmemo/nmemo.c"
#include "../nmidi/nmidi.c"
#include "../nmixer/nmixer.c"
#include "../nonnon paint/nonnon_paint.c"
#include "../ntyping/ntyping.c"
#include "../nyaurism/nyaurism.c"
#include "../orangecat/orangecat.c"
#include "../projectchecker/projectchecker.c"
#include "../pentrainer/pentrainer.c"
#include "../watchcat/watchcat.c"
#include "../wheel_axl/wheel_axl.c"




LRESULT CALLBACK
n_apps_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_project_darkmode();

		n_project_dialog_info( hwnd, n_posix_literal( "Welcome!" ) );

		return -1;

	break;

	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch

	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{

	// [!] : for backward compatibility

	n_apps_register();


	// [!] : Start

	n_posix_char *cmdline = n_win_commandline_new();

	if ( n_string_commandline_option( N_APPS_OPTION_N_ATTRIB, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_N_ATTRIB );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_attrib_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_CALENDAR, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_CALENDAR );

//n_posix_debug_literal( "%s", cmdline );
		n_bool sticky_onoff = ( n_false == n_string_is_empty( cmdline ) );

		n_string_path_free( cmdline );

		if ( sticky_onoff )
		{
			return (int) n_win_main( N_APPS_NAME_CALENDAR, n_calendar_wndproc );
		} else {
			return (int) n_win_main(                 NULL, n_calendar_wndproc );
		}

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_CATPAD, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_CATPAD );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_catpad_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_CHARMAP, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_CHARMAP );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_charmap_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_FELIS, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_FELIS );

		n_string_path_free( cmdline );

		return (int) n_felis_main( NULL, n_felis_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_FTP, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_FTP );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_ftp_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_MARIE, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_MARIE );

		n_string_path_free( cmdline );

		return (int) n_marie_main();

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NEKO_NO_TE, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NEKO_NO_TE );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_nekonote_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NMEMO, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NMEMO );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_nmemo_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NMIDI, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NMIDI );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_nmidi_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NMIXER, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NMIXER );

//n_posix_debug_literal( "%s", cmdline );
		n_bool sticky_onoff = ( n_false == n_string_is_empty( cmdline ) );

		n_string_path_free( cmdline );

		if ( sticky_onoff )
		{
			return (int) n_win_main( N_APPS_NAME_NMIXER, n_nmixer_wndproc );
		} else {
			return (int) n_win_main(               NULL, n_nmixer_wndproc );
		}

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NONNON_PAINT, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NONNON_PAINT );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_paint_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NTYPING, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NTYPING );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_typing_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NYAURISM, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_NYAURISM );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_nyaurism_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_ORANGECAT, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_ORANGECAT );

		n_string_path_free( cmdline );

		return (int) n_game_main();

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_PROJECTCHECKER, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_PROJECTCHECKER );

		n_string_path_free( cmdline );

		return (int) n_win_main( NULL, n_pc_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_PENTRAINER, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_PENTRAINER );

		n_string_path_free( cmdline );

		return (int) n_pentrainer_main();

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_WATCHCAT, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_WATCHCAT );

		n_string_path_free( cmdline );

		return (int) n_win_main( N_APPS_NAME_WATCHCAT, n_watchcat_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_WHEEL_AXL, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_WHEEL_AXL );

		n_string_path_free( cmdline );

		return (int) n_win_main( N_APPS_NAME_WHEEL_AXL, n_wheel_axl_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_WHITENOISE, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_WHITENOISE );

		n_string_path_free( cmdline );

		return (int) n_win_main( N_APPS_NAME_WHITENOISE, n_whitenoise_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_PINKNOISE, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_PINKNOISE );

		n_string_path_free( cmdline );

		return (int) n_win_main( N_APPS_NAME_PINKNOISE, n_pinknoise_wndproc );

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_NONNON, cmdline ) )
	{

		n_posix_char *nmixer    = n_posix_literal( "nonnonapps.exe -nmixer sticky" );
		n_posix_char *pinknoise = n_posix_literal( "nonnonapps.exe -pinknoise" );

		n_win_exec(    nmixer, SW_MINIMIZE );
		n_win_exec( pinknoise, SW_MINIMIZE );

		if ( n_sysinfo_version_10_or_later() )
		{
			//
		} else {
			n_posix_char *wheelaxl  = n_posix_literal( "nonnonapps.exe -wheel_axl" );
			n_win_exec(  wheelaxl, SW_MINIMIZE );
		}

		return n_false;

	} else

	if ( n_string_commandline_option( N_APPS_OPTION_SLEEPY, cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_SLEEPY );

		n_win_message_post( n_win_hwnd_find_literal( NULL, "Progman" ), WM_CLOSE, 0,0 );

		n_string_path_free( cmdline );

		return n_false;

	} else

	if ( n_false == n_bat_main( cmdline ) )
	{

		n_apps_taskbar( N_APPS_NAME_BATCHDROP );

		n_string_path_free( cmdline );

		return n_false;

	} else

	if ( n_false == n_favorites2html_main( cmdline ) )
	{

		n_explorer_refresh( n_false );

		n_string_path_free( cmdline );

		return n_false;

	} else

	if ( n_false == n_floppy_main( cmdline ) )
	{

		n_explorer_refresh( n_false );

		n_string_path_free( cmdline );

		return n_false;

	}// else


	n_string_path_free( cmdline );


	// [!] : Link maker

	n_win_exedir2curdir();

	n_apps_shortcut_calendar();
	n_apps_shortcut_catpad();
	n_apps_shortcut_charmap();
	n_apps_shortcut_felis();
	n_apps_shortcut_ftp();
	n_apps_shortcut_marie();
	n_apps_shortcut_mixer();
	n_apps_shortcut_neko_no_te();
	n_apps_shortcut_nmemo();
	n_apps_shortcut_nmidi();
	n_apps_shortcut_nonnon_paint();
	n_apps_shortcut_ntyping();
	n_apps_shortcut_nyaurism();
	n_apps_shortcut_n_attrib();
	n_apps_shortcut_orangecat();
	n_apps_shortcut_projectchecker();
	n_apps_shortcut_pentrainer();
	n_apps_shortcut_watchcat();
	n_apps_shortcut_wheel_axl();
	n_apps_shortcut_whitenoise();
	n_apps_shortcut_pinknoise();
	n_apps_shortcut_sleepy();


	return (int) n_win_main( NULL, n_apps_wndproc );
}

