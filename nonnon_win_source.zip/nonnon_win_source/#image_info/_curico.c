// Nonnon Image Info
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_imageinfo_curico( n_posix_char *name, n_win_txtbox *txtbox )
{

	int cb = sizeof( n_curico );

	if ( cb > n_posix_stat_size( name ) ) { return; }


	n_curico curico;


	FILE *fp = n_posix_fopen_read( name );
	if ( fp != NULL )
	{
		fread( &curico, cb, 1, fp );
	}
	fclose( fp );


	n_posix_char *str = n_string_new( 1024 );


	n_posix_sprintf_literal
	(
		str,

		"[ ICONDIR ]\n"
		"u16 zero1    = %d\n"
		"u16 type     = %d\n"
		"u16 count    = %d\n"
		"\n"
		"[ ICONDIRENTRY ]\n"
		"u8  sx       = %lu\n"
		"u8  sy       = %ld\n"
		"u8  colors   = %ld\n"
		"u8  zero2    = %d\n"

		"u16 hotspotx = %d\n"
		"u16 hotspoty = %d\n"
		"u32 bmpsize  = %lu\n"
		"u32 offset   = %lu\n",

		curico.zero1,
		curico.type,
		curico.count,

		curico.sx,
		curico.sy,
		curico.colors,
		curico.zero2,

		curico.hotspotx,
		curico.hotspoty,
		curico.bmpsize,
		curico.offset

	);


	n_win_txtbox_txt_load_onmemory( txtbox, str, 1024 );


	return;
}


