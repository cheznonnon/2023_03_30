// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_nyaurism_player_init( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h != NULL ) { return; }


	waveOutOpen( h, WAVE_MAPPER, &N_WAV_FMT( wav ), 0,0,CALLBACK_NULL );

	N_WAV_LOOP( wav ) = 1;

	waveOutPrepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );
	waveOutReset( *h );


	return;
}

void
n_nyaurism_player_go( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveOutWrite( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );


	return;
}

void
n_nyaurism_player_exit( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveOutReset( *h );
	waveOutUnprepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );

	waveOutClose( *h );

	(*h) = NULL;


	return;
}

void
n_nyaurism_recorder_init( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h != NULL ) { return; }


	waveInOpen( h, WAVE_MAPPER, &N_WAV_FMT( wav ), 0,0,CALLBACK_NULL );

	N_WAV_LOOP( wav ) = 1;

	waveInPrepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );
	waveInReset( *h );

	waveInAddBuffer( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );


	return;
}

void
n_nyaurism_recorder_go( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveInStart( *h );


	return;
}

void
n_nyaurism_recorder_exit( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveInReset( *h );
	waveInUnprepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );

	waveInClose( *h );

	(*h) = NULL;


	return;
}

