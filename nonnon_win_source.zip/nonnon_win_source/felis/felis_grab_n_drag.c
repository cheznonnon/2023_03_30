// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File


// [x] : compatibility
//
//	9x    : NG : [?] : hook is not available
//	2000  : OK
//	XP    : OK
//	Vista : OK
//	7     : OK
//	8.1   : OK
//	10    : OK




static n_win_grab_n_drag n_felis_grab_n_drag;




void
n_felis_grab_n_drag_cursor_change( IWebBrowser2 *_this, n_posix_bool onoff )
{

	// [x] : once set, but you cannot change to default state

	IHTMLDocument2  *hd2 = n_IWebBrowser2_MSHTML( _this );
	IHTMLStyleSheet *hss = NULL;

	if ( hd2 != NULL )
	{
		IHTMLDocument2_createStyleSheet( hd2, NULL, 0, (void*) &hss );
		if ( hss != NULL )
		{
			BSTR bstr;
			if ( onoff )
			{
				bstr = n_com_bstr_init_literal( "body { cursor : move; }" );
			} else {
				bstr = n_com_bstr_init_literal( "body { cursor : default; }" );
			}

			hss->lpVtbl->put_cssText( hss, bstr );

			n_com_bstr_exit( bstr );
		}
	}

	n_com_release( hss );
	n_com_release( hd2 );


	return;
}

void
n_felis_grab_n_drag_scroll( IWebBrowser2 *_this, int x, int y )
{

	if ( _this == NULL ) { return; }


	IHTMLDocument2 *hd2 = n_IWebBrowser2_MSHTML( _this );
	IHTMLWindow2   *hw2 = NULL;

	if ( hd2 != NULL )
	{
		IHTMLDocument2_get_parentWindow( hd2, &hw2 );
		if ( hw2 != NULL )
		{
			IHTMLWindow2_scrollBy( hw2, x,y );
		}
	}

	n_com_release( hw2 );
	n_com_release( hd2 );


	return;
}

void
n_felis_grab_n_drag_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	if ( nCode == HC_ACTION )
	{

		if ( n_felis_hwnd != GetActiveWindow() )
		{
			return;
		}

		if ( wParam == WM_MBUTTONDOWN )
		{

			// [x] : change a cursor : currently not supported
			//n_win_cursor_add( H_WB, IDC_SIZEALL );

			//n_felis_grab_n_drag_cursor_change( n_felis_wb, n_posix_true );


			n_win_grab_n_drag_zero( &n_felis_grab_n_drag );
			n_win_grab_n_drag_init( &n_felis_grab_n_drag, n_felis_hwnd );


			n_felis_grab_n_drag.inertia_onoff = n_posix_true;

		} else
		if ( wParam == WM_MOUSEMOVE )
		{

			int dx,dy;
			if ( n_win_grab_n_drag_loop( &n_felis_grab_n_drag, &dx, &dy ) ) { return; }

			n_felis_grab_n_drag_scroll( n_felis_wb, dx, dy );

		} else
		if ( wParam == WM_MBUTTONUP )
		{

			// [x] : change a cursor : currently not supported
			//n_win_cursor_add( H_WB, IDC_ARROW );

			//n_felis_grab_n_drag_cursor_change( n_felis_wb, n_posix_false );


			n_win_grab_n_drag_exit( &n_felis_grab_n_drag );

		}

	}


	return;
}

n_posix_bool
n_felis_grab_n_drag_inertia( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETCURSOR :

		// [x] : not working

		//n_win_cursor_add( NULL, IDC_SIZEALL );

		//return n_posix_true;

	break;


	case WM_MOUSEACTIVATE :

		n_win_grab_n_drag_exit( &n_felis_grab_n_drag );

	break;


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		int dx,dy;
		if ( n_win_grab_n_drag_inertia( &n_felis_grab_n_drag, wparam, &dx, &dy ) ) { break; }


		n_felis_grab_n_drag_scroll( n_felis_wb, dx, dy );

	}
	break;


	} // switch


	return n_posix_false;
}


