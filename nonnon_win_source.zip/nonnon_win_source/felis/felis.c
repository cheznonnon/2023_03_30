// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : IE/Trident : too buggy and compatibility hell
//
//	[ Task List ]
//
//	currently nothing
//
//	[ Maybe Not Needed ]
//
//	DISPID_AMBIENT_DLCONTROL : CLSID_WebBrowser has IOleControl but DISPID_* is not sent




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"




//#define N_COM_DEBUG_ONOFF

#include "../nonnon/com/WebBrowser.c"


#include "../nonnon/game/helper.c"


#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/www.c"


#include "../nonnon/win32/clipboard.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/registry.c"

#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_richdialog.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/win32/gdi/doublebuffer_32bpp.c"


#include "../nonnon/project/macro.c"




// [!] : Shared Component

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_FELIS ( 0 )

#endif // #ifndef NONNON_APPS


#define H_BAND   n_felis_hgui[ 0 ]
#define H_FRAME  n_felis_hgui[ 1 ]
#define H_WB     n_felis_hgui[ 2 ]
#define H_DEBUG  n_felis_hgui[ 3 ]
#define H_URL    n_felis_hgui[ 4 ]
#define H_ACCESS n_felis_hgui[ 5 ]
#define H_BLOCK  n_felis_hgui[ 6 ]
#define GUI_MAX                7

#define H_BACK   n_felis_hbtn[ 0 ]
#define H_LOAD   n_felis_hbtn[ 1 ]
#define H_STOP   n_felis_hbtn[ 2 ]
#define H_HOME   n_felis_hbtn[ 3 ]
#define H_ICPL   n_felis_hbtn[ 4 ]
#define H_EXHI   n_felis_hbtn[ 5 ]
#define H_STAR   n_felis_hbtn[ 6 ]
#define BTN_MAX                7


#define H_OPEN   n_felis_txtbox_open.hwnd




static HWND             n_felis_hwnd = NULL;
static HWND             n_felis_hgui[ GUI_MAX ];
static n_win_button     n_felis_hbtn[ BTN_MAX ];

static n_posix_char    *n_felis_exepath;
static IWebBrowser2    *n_felis_wb     = NULL;
static DWORD            n_felis_cookie = 0;
static BSTR             n_felis_url_current;
static BSTR             n_felis_url_hovered;
static BSTR             n_felis_url_lastset;

static n_bool           n_felis_is_hovered   = n_false;
static void            *n_felis_disp2release = NULL;
static HHOOK            n_felis_hhook        = NULL;
static HHOOK            n_felis_hhook_ll     = NULL;

static n_bool           n_felis_mousegesture_onoff  = n_false;
static POINT            n_felis_mousegesture_pt_prv = { -1,-1 };
static POINT            n_felis_mousegesture_pt_cur = { -1,-1 };

static n_win_txtbox     n_felis_txtbox_open;

static n_bool           n_felis_addressbar_draw_onoff = n_true;
static n_bool           n_felis_dwm_transbg_onoff     = n_false;

static n_win_titlemenu  n_felis_titlemenu;
static n_win_simplemenu n_felis_simplemenu;




#define N_FELIS_PROGRESS_FADE_PHASE_NONE ( 0 )
#define N_FELIS_PROGRESS_FADE_PHASE_INIT ( 1 )
#define N_FELIS_PROGRESS_FADE_PHASE_LOOP ( 2 )


static UINT          n_felis_progress_timer_id = 0;
static UINT          n_felis_progress_timer_delay;
static n_type_gfx    n_felis_progress_x;
static n_type_gfx    n_felis_progress_sx;
static n_bool        n_felis_progress_stop_onoff = n_false;
static n_bool        n_felis_progress_fade_phase = N_FELIS_PROGRESS_FADE_PHASE_NONE;
static n_bmp_fade    n_felis_progress_fade;




#include "./_debug.c"
#include "./_inetcpl.c"




// [!] : Component

void
n_felis_webbrowser_autoresize( n_bool notify )
{

	n_type_gfx sx,sy; n_win_size( H_FRAME, &sx,&sy );

	if ( notify ) { n_WebBrowser_resize( n_felis_wb, sx,sy ); }

	n_win_move_simple( H_WB, 0,0,sx,sy, n_true );


	return;
}


#include "./felis_tool.c"

#include "./felis_accesslist.c"
#include "./felis_addressbar.c"

#include "./com_IDocHostUIHandler.c"

#include "./com_HTMLDocumentEvents.c"
#include "./com_DWebBrowserEvents2.c"

#include "./felis_main.c"

#include "./felis_grab_n_drag.c"




#define n_felis_menu_id_base ( 100 )




#ifndef _WIN64
static WNDPROC n_felis_band_pfunc = NULL;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_felis_band_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_felis_band_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_COMMAND :

		if ( (HWND) lparam == H_BACK.hwnd )
		{

			n_WebBrowser_back( n_felis_wb );

		} else
		if ( (HWND) lparam == H_LOAD.hwnd )
		{

			if ( n_felis_wb == NULL )
			{

				// [!] : possible in  CLSID_InternetExplorer only

				n_posix_char *s = n_com_bstr2string( n_felis_url_current );

				n_felis_init( s );

				n_memory_free( s );

			} else {

				n_WebBrowser_load( n_felis_wb );

			}

		} else
		if ( (HWND) lparam == H_STOP.hwnd )
		{

			ShowWindow( H_STOP.hwnd, SW_HIDE   );
			ShowWindow( H_LOAD.hwnd, SW_NORMAL );

			n_WebBrowser_stop( n_felis_wb );

		} else
		if ( (HWND) lparam == H_HOME.hwnd )
		{

			n_WebBrowser_stop( n_felis_wb );
			n_felis_addressbar_exit();


			// [Buggy] : size will be invalid when do IWebBrowser2_GoHome()

			n_felis_webbrowser_autoresize( n_true );


			BSTR bstr = n_com_bstr_init( n_felis_url_home );

			// [x] : hangup while loading

			n_WebBrowser_go( n_felis_wb, bstr );

			n_com_bstr_exit( bstr );

		} else
		if ( (HWND) lparam == H_ICPL.hwnd )
		{

			n_posix_char *inetcpl = n_posix_literal( "rundll32 shell32.dll,Control_RunDLL inetcpl.cpl,,1" );
			n_win_exec( inetcpl, SW_NORMAL );

		} else
		if ( (HWND) lparam == H_EXHI.hwnd )
		{
//n_HTMLDocumentEvents_useragent(); break;
//n_felis_security(); break;


			n_clipboard_text_set( hwnd, N_STRING_EMPTY );

			n_inetcpl_extremehigh();

			n_felis_history_clear( n_win_hwnd_toplevel( hwnd ) );

		} else
		if ( (HWND) lparam == H_STAR.hwnd )
		{
//n_felis_register(); break;
//n_felis_select2go( n_felis_wb ); break;

			// [!] : don't use H_URL's text

			BSTR bstr = n_WebBrowser_title( n_felis_wb );

			n_posix_char *title = n_com_bstr2string( bstr );
			n_posix_char *url   = n_com_bstr2string( n_felis_url_current );

			n_felis_urlfile_save( title, url );
			//n_clipboard_text_set( hwnd, url );

			n_memory_free( title );
			n_memory_free( url );

			n_com_bstr_exit( bstr );

		} //else

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BACK );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_LOAD );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_STOP );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_HOME );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_ICPL );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_EXHI );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_STAR );


	n_felis_addressbar_proc( hwnd, msg, wparam, lparam, H_URL );


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_felis_band_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_felis_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx gap = H_BACK.maclike_offset / 2;


	static n_bool is_first = n_true;


	int        nwset = N_WIN_SET_DEFAULT;
	n_type_gfx csx   = -1;
	n_type_gfx csy   = -1;

	if ( is_first )
	{

		n_win_desktop_size( &csx, &csy );

		is_first = n_false;
		nwset    = N_WIN_SET_CENTERING;
		csx      = (n_type_gfx) ( (n_type_real) csx * 0.8 );
		csy      = (n_type_gfx) ( (n_type_real) csy * 0.8 );

		if ( csx > csy )
		{
			csx= (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );
		}

	} else {

		nwset = n_project_n_win_set();

	}

	n_win w; n_win_set( hwnd, &w, csx,csy, nwset );

	n_felis_addressbar_show();
	n_felis_accesslist_show();


	n_type_gfx ico_x = 0;

	n_win_button_move_toolband( &H_BACK, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;
	n_win_button_move_toolband( &H_LOAD, ico_x, 0, ico,ico, redraw );
	n_win_button_move_toolband( &H_STOP, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;
	n_win_button_move_toolband( &H_HOME, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;
	n_win_button_move_toolband( &H_ICPL, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;
	n_win_button_move_toolband( &H_EXHI, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;
	n_win_button_move_toolband( &H_STAR, ico_x, 0, ico,ico, redraw ); ico_x += ico + gap;

	n_type_gfx band_sy = ico + gap;

	{

		n_type_gfx bar_sx = w.csx - ico_x;
		n_type_gfx bar_sy = ctl;
		n_type_gfx bar_x  = ico_x + ( m * 2 );
		n_type_gfx bar_y  = ( band_sy - bar_sy ) / 2;

		bar_sx -= ( m * 2 ) * 2;

		n_win_txtbox *h_open = &n_felis_txtbox_open;

		n_win_move       ( H_URL , bar_x, bar_y, bar_sx, bar_sy, redraw );
		n_win_txtbox_move( h_open, bar_x, bar_y, bar_sx, bar_sy, redraw );

	}

	n_win_move_simple( H_BAND,   0,       0, w.csx,     band_sy, redraw );
	n_win_move_simple( H_FRAME,  0, band_sy, w.csx, w.csy - ico, redraw );

	{

		n_type_gfx sx = w.csx / 2;

		n_win_move_simple( H_ACCESS,  0, band_sy, sx, w.csy - ico, redraw );
		n_win_move_simple( H_BLOCK , sx, band_sy, sx, w.csy - ico, redraw );

	}

	// [x] : static control will not refresh text while resizing

	if ( H_WB != NULL )
	{
		n_felis_webbrowser_autoresize( n_false );
	} else {
		//n_win_text_set_literal( H_FRAME, "Press Reload Button" );
	}


	return;
}

int
n_felis_txtbox_input_style( void )
{

	int style = N_WIN_TXTBOX_STYLE_ONELINE | N_WIN_TXTBOX_STYLE_EDITBOX;

	if ( n_felis_dwm_transbg_onoff )
	{
		style |= N_WIN_TXTBOX_STYLE_TRANSBG;
	} else {
		if ( n_sysinfo_version_vista_or_later() )
		{
			style |= N_WIN_TXTBOX_STYLE_VISIBLE;
		}
	}


	return style;
}

LRESULT CALLBACK
n_felis_MouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	// [Needed] : IE5 or earlier
	//
	//	an auto-scroll cursor will be suppressed

	// [!] : Win95 + IE4 : crash : don't use n_win_message_remove()


	if ( nCode == HC_ACTION )
	{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), "%d", wParam );

		//MOUSEHOOKSTRUCT *p = (void*) lParam;

		static int phase = 0;
		static u32 timer = 0;

		if ( wParam == WM_MBUTTONDOWN )
		{

			if ( phase == 0 )
			{
				phase = 1;
				timer = n_posix_tickcount();
			} else
			if ( phase == 2 )
			{
				phase = 3;
				if ( ( timer + GetDoubleClickTime() ) < n_posix_tickcount() )
				{
					phase = 1;
					timer = n_posix_tickcount();
				}
			}
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), " phase = %d ", phase );


			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_WebBrowser_zoom_default( n_felis_wb );
			}

			return n_true;

		} else
		if ( wParam == WM_MBUTTONUP )
		{

			if ( phase == 1 )
			{
				phase = 2;
			} else
			if ( phase == 3 )
			{
				phase = 0;

				if ( ( timer + ( GetDoubleClickTime() * 2 ) ) >= n_posix_tickcount() )
				{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), "double-clicked" );

					MOUSEHOOKSTRUCT *p = (void*) lParam;

					if (
						( n_win_class_is_same_literal( p->hwnd, "window #0" ) )
						||
						( n_win_class_is_same_literal( p->hwnd, "Static"    ) )
					)
					{
						POINT pt; GetCursorPos( &pt );
						n_win_mbutton2centering_proc( p->hwnd, WM_NCMBUTTONDBLCLK, HTCAPTION, (LPARAM) &pt );
					}

				}
			}
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( H_WB ), " phase = %d ", phase );


			if ( n_felis_select2go( n_felis_wb ) )
			{

				//

			} else
			if ( n_felis_is_hovered )
			{

				n_felis_newwindow( n_felis_url_hovered );

			}

		}

	}


	return CallNextHookEx( n_felis_hhook, nCode, wParam, lParam );
}

LRESULT CALLBACK
n_felis_LowLevelMouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{

	if ( nCode == HC_ACTION )
	{

		if ( n_felis_hwnd != GetActiveWindow() )
		{
			return CallNextHookEx( n_felis_hhook_ll, nCode, wParam, lParam );
		}


		if ( wParam == WM_XBUTTONUP )
		{

			MSLLHOOKSTRUCT *p = (void*) lParam;

			int code = 0;
			if ( p != NULL ) { code = HIWORD( p->mouseData ); }

			if ( code & XBUTTON1 )
			{
				n_WebBrowser_back( n_felis_wb );
			} else
			if ( code & XBUTTON2 )
			{
				n_WebBrowser_next( n_felis_wb );
			}

		}

		n_felis_grab_n_drag_MouseProc( nCode, wParam, lParam );

	}

	return CallNextHookEx( n_felis_hhook_ll, nCode, wParam, lParam );
}

void
n_felis_icon_add( void )
{

	n_posix_char *exe = n_win_exepath_new();

	n_win_icon_init_callback = n_project_system_icon_color;

	H_BACK.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_LOAD.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_STOP.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_HOME.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 5, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_ICPL.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 6, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_EXHI.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 7, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_STAR.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_FELIS + 8, N_WIN_ICON_INIT_OPTION_RESOURCE );

	n_string_path_free( exe );


	return;
}

void
n_felis_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_refresh( H_BAND, n_true );

		n_felis_icon_add();

		n_win_button_on_settingchange( &H_BACK );
		n_win_button_on_settingchange( &H_LOAD );
		n_win_button_on_settingchange( &H_STOP );
		n_win_button_on_settingchange( &H_HOME );
		n_win_button_on_settingchange( &H_ICPL );
		n_win_button_on_settingchange( &H_EXHI );
		n_win_button_on_settingchange( &H_STAR );

		n_win_txtbox_on_settingchange( &n_felis_accesslist_txtbox[ 0 ] );
		n_win_txtbox_on_settingchange( &n_felis_accesslist_txtbox[ 1 ] );


		n_felis_dwm_transbg_onoff = n_project_dwm_is_on();

		n_felis_txtbox_open.style = n_felis_txtbox_input_style();

		n_win_txtbox_on_settingchange( &n_felis_txtbox_open );

	break;


	} // switch


}

LRESULT CALLBACK
n_felis_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_felis_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :

//n_project_window_resizable( hwnd ); ShowWindowAsync( hwnd, SW_NORMAL ); break;


		// Global

		n_felis_hwnd = hwnd;

		n_game_timegettime_init();

		n_felis_exepath = n_win_exepath_new();

		if ( n_felis_not_supported() ) { return -1; }

		n_win_exedir2curdir();
		n_felis_ini_read();

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_felis_dwm_transbg_onoff = n_project_dwm_is_on();


		// [x] : Vista : Web Browser control will be seme-transparent

		//if ( n_false == n_sysinfo_version_10_or_later() )
		{
			//n_project_toolband_mode = N_PROJECT_TOOLBAND_MODE_ALL;
		}


		n_win_button_zero( &H_BACK );
		n_win_button_zero( &H_LOAD );
		n_win_button_zero( &H_STOP );
		n_win_button_zero( &H_HOME );
		n_win_button_zero( &H_ICPL );
		n_win_button_zero( &H_EXHI );
		n_win_button_zero( &H_STAR );


		// Window

		n_win_init_literal( hwnd, "Felis Local Web Browser", "FELIS_0_MAIN", "" );

		{

			// [x] : parent is hwnd : inaccurate but cannot touch

			int style        = n_felis_txtbox_input_style();
			int style_option = N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;

			if (
				( n_win_darkmode_onoff == n_posix_false )
				&&
				( n_win_dwm_is_on() )
			)
			{
				style_option |= N_WIN_TXTBOX_OPTION_PARENT_BACKGRND;
			}

			if ( n_win_style_is_classic() )
			{
				//
			} else
			if (
				( n_win_darkmode_onoff )
				||
				( n_posix_false == n_win_dwm_aeroglass_is_on() )
			)
			{
				style_option |= N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT;
				style_option |= N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE;
			}

			n_win_txtbox_init( &n_felis_txtbox_open, hwnd, style, style_option );

#ifdef _WIN64
			SetWindowSubclass( H_OPEN, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_felis_addressbar_on_keydown );
#else  // #ifdef _WIN64
			n_win_property_init_literal
			(
				H_OPEN,
				"n_win_subclass_txtbox_on_keydown()",
				(int) n_win_gui_subclass_set( H_OPEN, n_win_subclass_txtbox_on_keydown )
			);

			n_win_property_init_literal( H_OPEN, "WM_KEYDOWN", (int) n_felis_addressbar_on_keydown );
#endif // #ifdef _WIN64

		}


		n_win_gui_literal( hwnd,   CANVAS,  "", &H_BAND  );
		n_win_gui_literal( hwnd,   CANVAS,  "", &H_FRAME );
		n_felis_accesslist_init( hwnd );

		n_win_gui_literal( H_BAND, CANVAS,  "", &H_URL   );


		n_felis_debug_gui( hwnd, &H_DEBUG );


		n_felis_icon_add();


		// Style

		n_project_window_resizable( hwnd );

		n_win_button_init_dwm( &H_BACK, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_LOAD, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_STOP, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_HOME, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_ICPL, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_EXHI, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_STAR, H_BAND, N_STRING_EMPTY, PBS_NORMAL );

		n_project_toolband_dwm_onoff_margin = H_BACK.maclike_offset;

#ifdef _WIN64
		SetWindowSubclass( H_BAND, n_felis_band_subclass , 0, 0 );
#else  // #ifdef _WIN64
		n_felis_band_pfunc = n_win_gui_subclass_set( H_BAND, n_felis_band_subclass );
#endif // #ifdef _WIN64


		n_win_simplemenu_zero( &n_felis_simplemenu );
		n_win_simplemenu_init( &n_felis_simplemenu );

		n_win_simplemenu_set( &n_felis_simplemenu, 0, NULL, n_posix_literal( "[ ]User Agent Viewer" ), NULL );
		n_win_simplemenu_set( &n_felis_simplemenu, 1, NULL, n_posix_literal( "[v]Silent Mode"       ), NULL );
		n_win_simplemenu_set( &n_felis_simplemenu, 2, NULL, n_posix_literal( "[ ]Access List"       ), NULL );
		n_win_simplemenu_set( &n_felis_simplemenu, 3, NULL, n_posix_literal( "[-]"                  ), NULL );
		n_win_simplemenu_set( &n_felis_simplemenu, 4, NULL, n_posix_literal( "[ ]Make Default"      ), NULL );


		// Size

		n_felis_resize( hwnd );


		// Init

		n_felis_hhook = SetWindowsHookEx( WH_MOUSE, n_felis_MouseProc, GetModuleHandle( NULL ), GetWindowThreadProcessId( hwnd, NULL ) );
//if ( hhook == NULL ) { n_posix_debug_literal( "%d", (int) GetLastError() ); }

		n_felis_hhook_ll = SetWindowsHookEx( WH_MOUSE_LL, n_felis_LowLevelMouseProc, GetModuleHandle( NULL ) , 0 );

		n_win_titlemenu_init_main( &n_felis_titlemenu, hwnd, &n_felis_simplemenu );

		n_felis_url_current = n_com_bstr_init_literal( "" );
		n_felis_url_hovered = n_com_bstr_init_literal( "" );
		n_felis_url_lastset = n_com_bstr_init_literal( "" );

		H_WB       = NULL;
		n_felis_wb = NULL;

		{

			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_FELIS, cmdline );

#endif // #ifdef NONNON_APPS

			n_posix_char *urlname = n_felis_urlfile_load_new( cmdline );
//n_posix_debug_literal( "%s", urlname );

			if ( n_string_is_empty( urlname ) )
			{
				if ( n_string_is_empty( cmdline ) )
				{
					n_string_path_free( cmdline );
					cmdline = n_string_path_carboncopy( n_felis_url_home );
				}
			} else {
				n_string_path_free( cmdline );
				cmdline = n_string_path_carboncopy( urlname  );
			}

			n_felis_init( cmdline );

			n_string_path_free( cmdline );
			n_string_path_free( urlname );

			IWebBrowser2_put_Silent( n_felis_wb, VARIANT_TRUE );

		}

		n_win_stdfont_init( n_felis_hgui, GUI_MAX );

		n_win_txtbox_metrics_canvas( &n_felis_accesslist_txtbox[ 0 ] );
		n_win_txtbox_metrics_canvas( &n_felis_accesslist_txtbox[ 1 ] );


		// Display

//EnableWindow( H_WB, n_false );

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		// [Needed] : prevent redraw error

		return n_true;

	break;


	case WM_SIZE :
	{

		// [Patch] : scrollbar position is reset when restored after minimized

		// [x] : n_WebBrowser_focus() doesn't work

		// [x] : IE6 or earlier : EnableWindow() doesn't work


		// [x] : hang-up : don't use IWebBrowser2_get_Visible() to check

		static n_bool onoff = n_true;

		if ( wparam == SIZE_MINIMIZED )
		{

			onoff = n_false;
			IWebBrowser2_put_Visible( n_felis_wb, VARIANT_FALSE );

		} else {

			if ( onoff == n_false )
			{
				onoff = n_true;
				IWebBrowser2_put_Visible( n_felis_wb, VARIANT_TRUE );
			}

		}


		n_felis_resize( hwnd );

	}
	break;


	case WM_MOUSEWHEEL :

		if ( n_felis_addressbar_onoff ) { break; }
		if ( n_felis_accesslist_onoff ) { break; }

		// [Patch] : focus will be lost when inactivated or minimized

		// [x] : sync error will occur

		if ( ( H_WB != GetFocus() )&&( n_felis_on_navigation_lock == n_false ) )
		{
			n_WebBrowser_focus( n_felis_wb );
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			//n_felis_grab_n_drag_scroll( n_felis_wb, 0, 100 );

		} else
//
		if ( wparam == VK_F2 )
		{
//n_posix_debug_literal( " ! " );
			static n_bool onoff = n_false;

			if ( onoff == n_false )
			{

				onoff = n_true;

				n_felis_addressbar_progress_start( n_true, 0 );

			} else {

				onoff = n_false;

				n_felis_addressbar_progress_stop();

			}

		} else
//
		if ( ( wparam == 'L' )&&( n_win_is_input( VK_CONTROL ) ) )
		{

			// [!] : this is Firefox and IE compatible behavior

			n_felis_addressbar_onoff = n_felis_bool_toggle( n_felis_addressbar_onoff );
			n_felis_addressbar_show();

		} else
		if ( ( wparam == 'O' )&&( n_win_is_input( VK_CONTROL ) ) )
		{

			n_felis_addressbar_onoff = n_felis_bool_toggle( n_felis_addressbar_onoff );
			n_felis_addressbar_show();

		} else {

			if ( n_felis_addressbar_onoff ) { break; }
			if ( n_felis_accesslist_onoff ) { break; }

			n_WebBrowser_on_keydown( hwnd, msg, wparam, lparam, n_felis_wb, H_WB );

		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == H_OPEN )
		{

			if ( wparam == WM_IME_NOTIFY )
			{
				n_win_txtbox_ime_fade_go( &n_felis_txtbox_open            );
				n_win_txtbox_ime_fade_go( &n_felis_accesslist_txtbox[ 1 ] );

				return n_posix_true;
			}

		} else
		if ( (HWND) lparam == H_BLOCK )
		{

			if ( wparam == WM_IME_NOTIFY )
			{
				n_win_txtbox_ime_fade_go( &n_felis_txtbox_open            );
				n_win_txtbox_ime_fade_go( &n_felis_accesslist_txtbox[ 1 ] );

				return n_posix_true;
			}

		} else
		if ( (HWND) lparam == n_felis_simplemenu.hwnd )
		{

			n_win_simplemenu *p = &n_felis_simplemenu;

			static n_bool silent_check = n_false;
			static n_bool access_check = n_false;

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{

				if ( silent_check )
				{
					silent_check = n_false;

					if ( n_win_simplemenu_detect_literal( p, 1, ' ' ) )
					{
						n_win_simplemenu_tweak_literal( p, 1, 'v' );
					} else {
						n_win_simplemenu_tweak_literal( p, 1, ' ' );
					}
				}

				if ( access_check )
				{
					access_check = n_false;

					if ( n_win_simplemenu_detect_literal( p, 2, ' ' ) )
					{
						n_win_simplemenu_tweak_literal( p, 2, 'v' );
					} else {
						n_win_simplemenu_tweak_literal( p, 2, ' ' );
					}
				}

			} else
			if ( wparam == 0 )
			{

				n_win_simplemenu_hide( &n_felis_simplemenu );

				n_felis_info( hwnd );

			} else
			if ( wparam == 1 )
			{

				silent_check = n_true;

				if ( n_win_simplemenu_detect_literal( p, wparam, ' ' ) )
				{
//n_win_hwndprintf_literal( hwnd, " Silent Mode : ON " );
					IWebBrowser2_put_Silent( n_felis_wb, VARIANT_TRUE  );
				} else {
//n_win_hwndprintf_literal( hwnd, " Silent Mode : OFF " );
					IWebBrowser2_put_Silent( n_felis_wb, VARIANT_FALSE );
				}

			} else
			if ( wparam == 2 )
			{

				access_check = n_true;

				n_felis_accesslist_onoff = n_felis_bool_toggle( n_felis_accesslist_onoff );

				n_felis_accesslist_show();

			} else
			if ( wparam == 3 )
			{

				//

			} //else
			if ( wparam == 4 )
			{

				n_felis_register();

			} //else

		}

	break;


	case WM_MOUSEACTIVATE :
//n_posix_debug_literal( "" );

		n_win_simplemenu_hide( &n_felis_simplemenu );

	break;


	case WM_CLOSE :

		//n_project_toolband_mode = N_PROJECT_TOOLBAND_MODE_PARTIAL;
		//n_project_toolband_dwm_onoff( hwnd );


		ShowWindow( hwnd, SW_HIDE );


		n_felis_accesslist_exit( hwnd );


		if ( n_felis_wb != NULL ) { n_WebBrowser_stop( n_felis_wb ); }


		n_felis_addressbar_draw_onoff = n_false;
		n_felis_addressbar_exit();


		n_win_text_set( H_URL, N_STRING_EMPTY );
		n_win_txtbox_line_set( &n_felis_txtbox_open, 0, N_STRING_EMPTY );

		n_win_stdfont_exit( n_felis_hgui, GUI_MAX );


		n_felis_exit();


		n_win_button_exit( &H_BACK );
		n_win_button_exit( &H_LOAD );
		n_win_button_exit( &H_STOP );
		n_win_button_exit( &H_HOME );
		n_win_button_exit( &H_ICPL );
		n_win_button_exit( &H_EXHI );
		n_win_button_exit( &H_STAR );


		UnhookWindowsHookEx( n_felis_hhook );
		UnhookWindowsHookEx( n_felis_hhook_ll );


#ifdef _WIN64
		RemoveWindowSubclass( H_OPEN, n_win_subclass_txtbox_on_keydown, 0 );
#else  // #ifdef _WIN64
		n_win_property_exit_literal( H_OPEN, "n_win_subclass_txtbox_on_keydown()" );
		n_win_property_exit_literal( H_OPEN, "WM_KEYDOWN" );
#endif // #ifdef _WIN64


		n_win_titlemenu_exit( &n_felis_titlemenu );

		n_felis_simplemenu.silent_onoff = n_true;
		n_win_simplemenu_exit( &n_felis_simplemenu );


		n_win_txtbox_exit( &n_felis_txtbox_open );


		n_string_path_free( n_felis_exepath );


		n_game_timegettime_exit();


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_project_toolband_proc( hwnd, msg, wparam, lparam, H_BAND, n_true );


	n_win_cornercolor_proc( hwnd, msg, wparam, lparam );


	{
		n_posix_bool ret = n_felis_grab_n_drag_inertia( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_felis_txtbox_open );
		if ( ret ) { return ret; }
	}


	{
		int ret = n_felis_accesslist_loop( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_felis_main( NULL, n_felis_wndproc );
}

#endif // #ifndef NONNON_APPS


#undef H_BAND
#undef H_FRAME
#undef H_WB
#undef H_DEBUG
#undef H_URL
#undef H_ACCESS
#undef H_BLACK
#undef GUI_MAX

#undef H_BACK
#undef H_LOAD
#undef H_STOP
#undef H_HOME
#undef H_ICPL
#undef H_EXHI
#undef H_STAR
#undef BTN_MAX


#undef H_OPEN

