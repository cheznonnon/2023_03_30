// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define MSG_TITLE     "Config"
#define MSG_CHANNEL   "Channel"
#define MSG_BEAT      "Beat"




typedef struct {

	n_win_scroller hscr_channel;
	HWND           hgui_groupbox;
	HWND           hgui_beat_label;
	n_win_combo    hgui_beat_combo;
	n_win_button   hbtn_ok;
	n_win_button   hbtn_cancel;

	n_bool         onoff;

} n_nmidi_config;




// internal
void
n_nmidi_config_combo_getset( n_nmidi_config *p, n_bool getset )
{

	const n_posix_char *string_beat[] = {

		n_posix_literal( " 4 : Lullaby" ),
		n_posix_literal( " 8 : Pop / Rock" ),
		n_posix_literal( "12 : Soul / R&B" ),
		n_posix_literal( "16 : Fusion / Metal" ),
		n_posix_literal( "24 : Jazz" ),
		NULL

	};


	if ( getset )
	{

		n_posix_char *str = n_win_combo_selection_get( &p->hgui_beat_combo );

		int i = 0;
		n_posix_loop
		{//break;

			if ( n_string_is_same( str, string_beat[ i ] ) )
			{

				if ( i == 0 ) { canvas.unit = n_nmidi_beat2unit(  4 ); } else
				if ( i == 1 ) { canvas.unit = n_nmidi_beat2unit(  8 ); } else
				if ( i == 2 ) { canvas.unit = n_nmidi_beat2unit( 12 ); } else
				if ( i == 3 ) { canvas.unit = n_nmidi_beat2unit( 16 ); } else
				if ( i == 4 ) { canvas.unit = n_nmidi_beat2unit( 24 ); }

				break;

			}


			i++;
			if ( NULL == string_beat[ i ] ) { break; }
		}

	} else {

		int i = 0;
		n_posix_loop
		{

			n_txt_set( &p->hgui_beat_combo.txt, i, string_beat[ i ] );

			if (
				( ( i == 0 )&&(  4 == n_nmidi_unit2beat( canvas.unit ) ) )
				||
				( ( i == 1 )&&(  8 == n_nmidi_unit2beat( canvas.unit ) ) )
				||
				( ( i == 2 )&&( 12 == n_nmidi_unit2beat( canvas.unit ) ) )
				||
				( ( i == 3 )&&( 16 == n_nmidi_unit2beat( canvas.unit ) ) )
				||
				( ( i == 4 )&&( 24 == n_nmidi_unit2beat( canvas.unit ) ) )
			)
			{
				n_win_combo_selection_set_by_string( &p->hgui_beat_combo, string_beat[ i ] );
			}

			i++;
			if ( NULL == string_beat[ i ] ) { break; }
		}

	}


	return;
}

void
n_nmidi_config_resize( n_nmidi_config *p, HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );


	n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

	n_type_gfx  unit_x = n_posix_min_n_type_gfx( w.csx / 2, ico * 8 );
	n_type_gfx  unit_y = ctl * 6;

	n_type_gfx start_x = ( w.csx - unit_x ) / 2;
	n_type_gfx start_y = ( w.csy - unit_y ) / 2;

	{

		n_type_gfx  x = start_x - ( ico * 1 );
		n_type_gfx  y = start_y;
		n_type_gfx sx =  unit_x + ( ico * 2 );
		n_type_gfx sy =  unit_y;

		n_win_move( p->hgui_groupbox, x,y,sx,sy, redraw );

	}

	{

		n_type_gfx cmb    = n_posix_max_n_type_gfx( w.csx, w.csy );
		n_type_gfx half_x = unit_x / 2;
		n_type_gfx comb_x = half_x - 1;

		n_type_gfx x = start_x;
		n_type_gfx y = start_y + ctl;

		nwscr_move       ( &p->hscr_channel   , x,y, unit_x,ctl, redraw ); x = start_x; y += ctl;
		n_win_move       (  p->hgui_beat_label, x,y, half_x,ctl, redraw ); x += half_x;
		n_win_combo_move ( &p->hgui_beat_combo, x,y, comb_x,cmb, redraw ); x = start_x; y += ctl;
		y += ctl;
		n_win_button_move( &p->hbtn_ok        , x,y, half_x,ctl, redraw ); x += half_x;
		n_win_button_move( &p->hbtn_cancel    , x,y, half_x,ctl, redraw ); x += half_x;

	}

	n_win_scrollbar_draw_always( &p->hscr_channel.scrollbar, n_true );


	return;
}

void
n_nmidi_config_show( n_nmidi_config *p, HWND hwnd, HWND *hgui, int gui_max )
{

	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ 1 + i ], SW_HIDE );

		i++;
		if ( i >= ( gui_max - 1 ) ) { break; }
	}


	p->onoff = n_true;


	// [x] : BS_GROUPBOX doesn't function

	n_win_gui_literal( hwnd, LABEL , MSG_BEAT , &p->hgui_beat_label );

	n_win_button_init_literal( &p->hbtn_ok    , hwnd, "OK"    , PBS_NORMAL );
	n_win_button_init_literal( &p->hbtn_cancel, hwnd, "Cancel", PBS_NORMAL );

	n_win_scroller_zero( &p->hscr_channel );
	n_win_scroller_init_literal( &p->hscr_channel, hwnd, MSG_CHANNEL );

	n_win_combo_zero( &p->hgui_beat_combo );
	n_win_combo_init( &p->hgui_beat_combo, hwnd );

	n_win_gui_literal( hwnd, CANVAS, "", &p->hgui_groupbox );


	// Scroller

	n_win_scroller_scroll_parameter( &p->hscr_channel, 1, 10, N_CHANNEL_MAX - 1, canvas.line - 1, n_false );


	// Combobox

	n_nmidi_config_combo_getset( p, n_false );


	n_win_stdfont_init( &p->hgui_beat_label, 1 );


	n_nmidi_config_resize( p, hwnd );


	return;
}

void
n_nmidi_config_hide( n_nmidi_config *p, HWND hwnd, HWND *hgui, int gui_max, n_bool is_ok )
{

	// Combobox

	if ( is_ok )
	{
		n_nmidi_config_combo_getset( p, n_true );
	}


	n_win_stdfont_exit( &p->hgui_beat_label, 1 );

	n_win_scroller_exit( &p->hscr_channel );

	n_win_combo_silent = n_true;
	n_win_combo_exit( &p->hgui_beat_combo );

	n_win_button_exit( &p->hbtn_ok     );
	n_win_button_exit( &p->hbtn_cancel );

	DestroyWindow( p->hgui_beat_label );
	DestroyWindow( p->hgui_groupbox   );


	p->onoff = n_false;


	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ i ], SW_SHOW );

		i++;
		if ( i >= gui_max ) { break; }
	}


	return;
}

void
n_nmidi_config_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_nmidi_config *p, HWND *hgui, int gui_max )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_refresh( p->hgui_groupbox, n_true );

		n_win_scroller_on_settingchange( &p->hscr_channel );

		n_win_combo_on_settingchange( &p->hgui_beat_combo );

		n_win_button_on_settingchange( &p->hbtn_ok     );
		n_win_button_on_settingchange( &p->hbtn_cancel );

	break;


	case WM_SIZE :

		if ( p->onoff == n_false ) { break; }

		n_nmidi_config_resize( p, hwnd );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		if ( p->onoff == n_false ) { break; }

	break;


	case WM_COMMAND :
	{

		if ( p->onoff == n_false ) { break; }

		HWND h = (HWND) lparam;

		if ( h == n_win_scroller_scroll_hwnd( &p->hscr_channel ) )
		{

			canvas.line = 1 + (int) wparam;

			n_win_hwndprintf_literal( p->hscr_channel.value, "%d", canvas.line );

		} else
		if ( h == p->hbtn_ok.hwnd )
		{

			n_nmidi_config_hide( p, hwnd, hgui, gui_max, n_true  );

		} else
		if ( h == p->hbtn_cancel.hwnd )
		{

			n_nmidi_config_hide( p, hwnd, hgui, gui_max, n_false );

		}

	}
	break;


	} // switch


	n_win_group_proc( hwnd, msg, wparam, lparam, p->hgui_groupbox );


	n_win_scroller_proc( hwnd, msg, wparam, lparam, &p->hscr_channel );


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &p->hgui_beat_combo );


	n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_ok     );
	n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_cancel );


	return;
}


#undef MSG_TITLE
#undef MSG_CHANNEL
#undef MSG_BEAT

