// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	// alias

	HWND           hwnd_parent;
	int            channel_number;
	int            note_number;
	n_bool         is_header;


	// ui

	n_bool         onoff;

	HWND           hgui_groupbox;
	HWND           hgui_label;
	n_win_scroller hscr_sound;
	n_win_scroller hscr_panpot;
	HWND           hgui_line;
	n_win_scroller hscr_note;
	n_win_scroller hscr_volume;
	n_win_button   hbtn_ok;
	n_win_button   hbtn_cancel;

	UINT           timer_id;
	u32            timer_msec;

	//RECT           rect;


	// internal

	int            prv_sound;
	int            prv_panpot;
	int            prv_note;
	int            prv_volume;

} n_nmidi_config_note;




#define n_nmidi_config_note_zero( p ) n_memory_zero( p, sizeof( n_nmidi_config_note ) );

void
n_nmidi_config_note_resize( n_nmidi_config_note *p )
{

	if ( p == NULL ) { return; }


	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m,pad; n_win_stdsize( p->hwnd_parent, &ctl, &ico, &m ); pad = ctl / 4;

	n_type_gfx csy = ( ctl * 7 );
	n_type_gfx csx = n_posix_max_n_type_gfx( 320, (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) ) );


	n_type_gfx p_csx, p_csy; n_win_size_client( p->hwnd_parent, &p_csx, &p_csy );

	n_type_gfx sx = csx + m + ( pad * 2 );
	n_type_gfx sy = csy + m + ( pad * 2 );
	n_type_gfx  x = ( p_csx - sx ) / 2;
	n_type_gfx  y = ( p_csy - sy ) / 2;


	if ( n_win_fluent_ui_onoff )
	{
		n_win_fluent_ui_roundrect_region( p->hgui_groupbox, sx,sy, n_win_fluent_ui_round_param( p->hgui_groupbox ) );
	}

	n_win_move_simple( p->hgui_groupbox, x,y,sx,sy, redraw );


	x += pad;
	y += pad;

	n_type_gfx half = csx / 2;

	n_win_move       (  p->hgui_label , x + ( 0 * ctl )       , y + ( 0 * ctl ),  csx,ctl, redraw );
	nwscr_move       ( &p->hscr_sound , x + ( 0 * ctl )       , y + ( 1 * ctl ),  csx,ctl, redraw );
	nwscr_move       ( &p->hscr_panpot, x + ( 0 * ctl )       , y + ( 2 * ctl ),  csx,ctl, redraw );
	n_win_move       (  p->hgui_line  , x + ( 0 * ctl )       , y + ( 3 * ctl ),  csx,ctl, redraw );
	nwscr_move       ( &p->hscr_note  , x + ( 0 * ctl )       , y + ( 4 * ctl ),  csx,ctl, redraw );
	nwscr_move       ( &p->hscr_volume, x + ( 0 * ctl )       , y + ( 5 * ctl ),  csx,ctl, redraw );
	n_win_button_move( &p->hbtn_ok    , x + ( 0 * ctl )       , y + ( 6 * ctl ), half,ctl, redraw );
	n_win_button_move( &p->hbtn_cancel, x + ( 0 * ctl ) + half, y + ( 6 * ctl ), half,ctl, redraw );

	n_win_scrollbar_draw_always( &p->hscr_sound .scrollbar, n_true );
	n_win_scrollbar_draw_always( &p->hscr_panpot.scrollbar, n_true );
	n_win_scrollbar_draw_always( &p->hscr_note  .scrollbar, n_true );
	n_win_scrollbar_draw_always( &p->hscr_volume.scrollbar, n_true );


	return;
}

void
n_nmidi_config_note_show( n_nmidi_config_note *p )
{

	if ( p == NULL ) { return; }


	// Global

	p->onoff          = n_true;
	p->channel_number = canvas.channel_number;
	p->note_number    = canvas.hover_x;
	p->is_header      = ( p->note_number == 0 );


	// Data

	n_channel *c = &canvas.channel[ p->channel_number ];

	if ( p->is_header )
	{

		//nwscr_enable( p->hscr_note,   n_false );
		//nwscr_enable( p->hscr_volume, n_false );

		c->note   =  60;
		c->volume = 100;

	} else {

		n_midi_bmp_note_get( &canvas.data, p->channel_number, p->note_number, &c->note, &c->volume );

	}

	p->prv_sound  = c->sound;
	p->prv_panpot = c->panpot;
	p->prv_note   = c->note;
	p->prv_volume = c->volume;


	// Scrollers

	if ( p->channel_number == N_MIDI_RHYTHMCHANNEL )
	{
		nwscr_enable( &p->hscr_sound, n_false );
	} else {
		nwscr_enable( &p->hscr_sound, n_true  );
	}

	n_win_scroller_scroll_parameter( &p->hscr_sound,  1, 10, 127, c->sound , n_false );
	n_win_scroller_scroll_parameter( &p->hscr_panpot, 1, 32, 127, c->panpot, n_false );
	n_win_scroller_scroll_parameter( &p->hscr_note,   1, 10, 127, c->note  , n_false );
	n_win_scroller_scroll_parameter( &p->hscr_volume, 1, 32, 127, c->volume, n_false );


	// Show

	n_nmidi_bulk_enablewindow( n_false );

	n_nmidi_config_note_resize( p );

	ShowWindow(  p->hgui_groupbox   , SW_NORMAL );
	ShowWindow(  p->hgui_label      , SW_NORMAL );
	nwscr_show( &p->hscr_sound      , SW_NORMAL );
	nwscr_show( &p->hscr_panpot     , SW_NORMAL );
	ShowWindow(  p->hgui_line       , SW_NORMAL );
	nwscr_show( &p->hscr_note       , SW_NORMAL );
	nwscr_show( &p->hscr_volume     , SW_NORMAL );
	ShowWindow(  p->hbtn_ok    .hwnd, SW_NORMAL );
	ShowWindow(  p->hbtn_cancel.hwnd, SW_NORMAL );


	return;
}

void
n_nmidi_config_note_hide( n_nmidi_config_note *p, n_bool is_closed, n_bool is_ok )
{

	if ( p == NULL ) { return; }


	// Global

	p->onoff = n_false;


	// Data

	if ( is_ok )
	{

		n_channel *c = &canvas.channel[ p->channel_number ];

		if ( p->prv_sound != c->sound )
		{
			n_midi_bmp_channel_set( &canvas.data, p->channel_number, c->sound, c->panpot );
			n_nmidi_canvas_item_header( &canvas, p->channel_number, 0 );
		}

		if ( p->prv_panpot != c->panpot )
		{
			n_midi_bmp_channel_set( &canvas.data, p->channel_number, c->sound, c->panpot );
		}

		if ( p->is_header == n_false )
		{

			if (
				( p->prv_note   != c->note )
				||
				( p->prv_volume != c->volume )
			)
			{
				n_nmidi_canvas_note_set( &canvas, p->channel_number, p->note_number, c->note, c->volume );
			}

		}

		n_hmidiout_all( p->channel_number, c->sound, c->panpot, c->note, 0 );

	}


	// Hide

	ShowWindow(  p->hgui_groupbox   , SW_HIDE );
	ShowWindow(  p->hgui_label      , SW_HIDE );
	nwscr_show( &p->hscr_sound      , SW_HIDE );
	nwscr_show( &p->hscr_panpot     , SW_HIDE );
	ShowWindow(  p->hgui_line       , SW_HIDE );
	nwscr_show( &p->hscr_note       , SW_HIDE );
	nwscr_show( &p->hscr_volume     , SW_HIDE );
	ShowWindow(  p->hbtn_ok    .hwnd, SW_HIDE );
	ShowWindow(  p->hbtn_cancel.hwnd, SW_HIDE );

	n_nmidi_bulk_enablewindow( n_true );


	if ( is_closed ) { EnableWindow( H_STA_CANVAS, n_false ); }


	return;
}

void
n_nmidi_config_note_exit( n_nmidi_config_note *p )
{

	if ( p == NULL ) { return; }


	// Global

	n_win_timer_exit( p->hwnd_parent, p->timer_id );

	n_hmidiout_exit();


	// UI

	n_win_stdfont_exit( &p->hgui_label, 1 );

	n_win_button_exit( &p->hbtn_ok     );
	n_win_button_exit( &p->hbtn_cancel );

	n_win_scroller_exit( &p->hscr_sound  );
	n_win_scroller_exit( &p->hscr_panpot );
	n_win_scroller_exit( &p->hscr_note   );
	n_win_scroller_exit( &p->hscr_volume );

	DestroyWindow( p->hgui_label  );
	DestroyWindow( p->hgui_line   );


	n_nmidi_config_note_zero( p );


	return;
}

void
n_nmidi_config_note_init( n_nmidi_config_note *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


	// Global

	n_nmidi_config_note_zero( p );

	n_hmidiout_init();

	p->timer_id   = 1;
	p->timer_msec = 100;


	// UI

	p->hwnd_parent = hwnd_parent;

	n_win_gui_literal( p->hwnd_parent, CANVAS, "", &p->hgui_label  );
	n_win_gui_literal( p->hwnd_parent, CANVAS, "", &p->hgui_line   );
	n_win_button_init_literal( &p->hbtn_ok    , p->hwnd_parent, "OK"    , PBS_NORMAL );
	n_win_button_init_literal( &p->hbtn_cancel, p->hwnd_parent, "Cancel", PBS_NORMAL );

	n_win_scroller_init_literal( &p->hscr_sound , p->hwnd_parent, "Sound"  );
	n_win_scroller_init_literal( &p->hscr_panpot, p->hwnd_parent, "Panpot" );
	n_win_scroller_init_literal( &p->hscr_note  , p->hwnd_parent, "Note"   );
	n_win_scroller_init_literal( &p->hscr_volume, p->hwnd_parent, "Volume" );


	// [Needed] : for siblings priority

	n_win_gui_literal( p->hwnd_parent, CANVAS, "", &p->hgui_groupbox );


	n_win_stdfont_init( &p->hgui_label, 1 );


	return;
}

void
n_nmidi_config_note_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_nmidi_config_note *p )
{

	static UINT timer_id = 0;
	static UINT sound_go = 0;


	if ( p == NULL ) { return; }

	if ( p->onoff == n_false ) { return; }


	n_channel *c = &canvas.channel[ p->channel_number ];


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == p->timer_id )
		{
			n_hmidiout_all( p->channel_number, c->sound, c->panpot, c->note, 0 );
			break;
		}


		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		//n_win_refresh( p->hgui_groupbox, n_false );
		n_win_refresh( p->hgui_line    , n_false );

		n_win_scroller_on_settingchange( &p->hscr_sound  );
		n_win_scroller_on_settingchange( &p->hscr_panpot );
		n_win_scroller_on_settingchange( &p->hscr_note   );
		n_win_scroller_on_settingchange( &p->hscr_volume );

		n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_ok     );
		n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_cancel );

	break;


	case WM_SIZE :

		n_nmidi_config_note_resize( p );

	break;


	case WM_LBUTTONDOWN :
//n_win_hwndprintf_literal( hwnd, " WM_LBUTTONDOWN " );

		sound_go = n_false;

	break;

	case WM_LBUTTONUP :
//n_win_hwndprintf_literal( hwnd, " WM_LBUTTONUP " );

		sound_go = n_true;

	break;


	case WM_COMMAND :
	{

		n_bool sound_onoff = n_false;


		HWND h = (HWND) lparam;


		if ( h == n_win_scroller_scroll_hwnd( &p->hscr_sound ) )
		{

			int prv = c->sound;
			int cur = c->sound = (int) wparam;

			n_win_hwndprintf_literal( p->hscr_sound.value, "%d", c->sound );

			n_win_text_set( p->hgui_label, n_midi_string_instruments[ c->sound ] );


			if ( ( prv != cur )||( sound_go ) )
			{
				sound_onoff = n_true;
			}

		} else

		if ( h == n_win_scroller_scroll_hwnd( &p->hscr_panpot ) )
		{

			c->panpot = (int) wparam;

			n_win_hwndprintf_literal( p->hscr_panpot.value, "%d", c->panpot );

		} else

		if ( h == n_win_scroller_scroll_hwnd( &p->hscr_note ) )
		{

			int prv = c->note;
			int cur = c->note = (int) wparam;

			if ( p->channel_number == N_MIDI_RHYTHMCHANNEL )
			{

				n_win_text_set( p->hgui_label, n_midi_string_percussions[ c->note ] );

				n_win_hwndprintf_literal( p->hscr_note.value, "%d", c->note );

			} else {

				n_posix_char str[ 100 ];
				n_midi_string_notes_get( c->note, str );

				n_win_hwndprintf_literal( p->hscr_note.value, "%d (%s)", c->note, str );

			}


			if ( ( prv != cur )||( sound_go ) )
			{
				sound_onoff = n_true;
			}

		} else

		if ( h == n_win_scroller_scroll_hwnd( &p->hscr_volume ) )
		{

			int prv = c->volume;
			int cur = c->volume = (int) wparam;

			n_win_hwndprintf_literal( p->hscr_volume.value, "%d", c->volume );


			if ( ( prv != cur )||( sound_go ) )
			{
				sound_onoff = n_true;
			}

		} else

		if ( (HWND) lparam == p->hbtn_ok.hwnd )
		{
			n_nmidi_config_note_hide( p, n_false, n_true  );
		} else

		if ( (HWND) lparam == p->hbtn_cancel.hwnd )
		{
			n_nmidi_config_note_hide( p, n_false, n_false );
		}


		if ( sound_onoff )
		{

			SetTimer( hwnd, p->timer_id, p->timer_msec, NULL );
			n_hmidiout_all( p->channel_number, c->sound, c->panpot, c->note, c->volume );

		}

	}
	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( di->hwndItem == p->hgui_label )
		{
			n_win_fluent_ui_progress( p->hgui_label, -1 );
		}

	}
	break;


	} // switch


	{

		if ( n_win_fluent_ui_onoff )
		{

			//

		} else {

			u32 fg   = n_win_darkmode_systemcolor( COLOR_HIGHLIGHT );
			u32 bg   = n_win_darkmode_systemcolor( COLOR_BTNFACE   );
			int pc   = 0;
			int edge = EDGE_ETCHED;

			n_win_progressbar_proc( hwnd, msg, wparam, lparam, p->hgui_label, edge, pc, fg, bg );

		}

	}


	n_win_group_proc( hwnd, msg, wparam, lparam, p->hgui_groupbox );


	n_win_scroller_proc( hwnd, msg, wparam, lparam, &p->hscr_sound  );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &p->hscr_panpot );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &p->hscr_note   );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &p->hscr_volume );


	n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_ok     );
	n_win_button_proc( hwnd, msg, wparam, lparam, &p->hbtn_cancel );


	n_win_separator_proc( hwnd, msg, wparam, lparam, p->hgui_line, PS_SOLID );


	return;
}

