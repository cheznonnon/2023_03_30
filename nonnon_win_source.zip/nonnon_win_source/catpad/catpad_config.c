// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define H_CAUTION  hgui[ 0 ]
#define H_LBL_0    hgui[ 1 ]
#define H_LBL_1    hgui[ 2 ]
#define GUI_MAX          3




#define N_CATPAD_CONFIG_CAUTION n_posix_literal( "CAUTION : your file might be broken" )




static n_win_combo n_catpad_config_combo_charset;
static n_win_combo n_catpad_config_combo_newline;




void
n_catpad_config_font( HWND hgui )
{

	HFONT   hf = n_win_font_get( hgui );
	LOGFONT lf = n_win_font_hfont2logfont( hf );

	lf.lfWeight    = FW_BOLD;
	lf.lfItalic    = n_false;
	lf.lfUnderline = n_true;


	n_win_font_exit( hf );
	hf = n_win_font_logfont2hfont( &lf );

	n_win_font_set( hgui, hf, n_false );


	return;
}

LRESULT CALLBACK
n_catpad_config_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui[ GUI_MAX ];
	static int  unicode;
	static int  newline;

	static UINT timer_id       = 0;
	static UINT timer_id_flash = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == timer_id_flash )
		{
			n_win_timer_exit( hwnd, timer_id_flash );

			n_catpad_flashwindow_init();

			break;
		}


		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_combo_on_settingchange( &n_catpad_config_combo_charset );
		n_win_combo_on_settingchange( &n_catpad_config_combo_newline );


		if ( timer_id_flash == 0 ) { timer_id_flash = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id_flash, 500 );
		n_catpad_flashwindow_exit();

		n_win_txtbox_metrics( &n_catpad_txtbox_editor );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "Config", "", "" );


		n_win_gui_literal( hwnd, CANVAS, "", &H_CAUTION );
		n_win_gui_literal( hwnd, LABEL , "", &H_LBL_0   );
		n_win_gui_literal( hwnd, LABEL , "", &H_LBL_1   );


		n_win_combo_zero( &n_catpad_config_combo_charset );
		n_win_combo_init( &n_catpad_config_combo_charset, hwnd );

		n_win_combo_zero( &n_catpad_config_combo_newline );
		n_win_combo_init( &n_catpad_config_combo_newline, hwnd );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// Size

		n_win_stdfont_init( hgui, GUI_MAX );

		n_catpad_config_font( H_CAUTION );

		{

		const n_bool redraw = n_true;


		n_type_gfx ctl,m;
		n_win_stdsize( hwnd, &ctl, NULL, &m );

		n_type_gfx pad = m;

		m *= 2;

		n_type_gfx text_sx = 0;
		n_win_stdsize_text( H_CAUTION, N_CATPAD_CONFIG_CAUTION, &text_sx, NULL );

		n_type_gfx csy = ( ctl * 4 );
		n_type_gfx csx = (n_type_gfx) n_posix_max_n_type_real( (n_type_real) text_sx * 1.5, (n_type_real) csy * sqrt( 2 ) );


		n_win_set( hwnd, NULL, csx + ( pad * 2 ),csy + ( pad * 2 ), N_WIN_SET_CENTERING );


		n_type_gfx sx1_3 = csx / 3;
		n_type_gfx sx2_3 = csx / 3 * 2; sx2_3 += ( csx % 3 );
		n_type_gfx lbl   = ctl * 2;
		n_type_gfx cmb   = ctl * 4;

		n_win_combo *h_cmb_0 = &n_catpad_config_combo_charset;
		n_win_combo *h_cmb_1 = &n_catpad_config_combo_newline;

		n_type_gfx x = pad;
		n_type_gfx y = pad;

		n_win_move      ( H_CAUTION,       x, (0*ctl)+y,   csx,lbl, redraw );
		n_win_move      ( H_LBL_0,         x, (2*ctl)+y, sx1_3,ctl, redraw );
		n_win_combo_move( h_cmb_0,   sx1_3+x, (2*ctl)+y, sx2_3,cmb, redraw );
		n_win_move      ( H_LBL_1,         x, (3*ctl)+y, sx1_3,ctl, redraw );
		n_win_combo_move( h_cmb_1,   sx1_3+x, (3*ctl)+y, sx2_3,cmb, redraw );

		}


		// Init

		n_win_text_set( H_CAUTION, N_CATPAD_CONFIG_CAUTION );

		unicode = n_catpad_txtbox_editor.txt.unicode;
		newline = n_catpad_txtbox_editor.txt.newline;


		n_win_text_set_literal( H_LBL_0, "Character Set" );

		n_txt_set( &n_catpad_config_combo_charset.txt, 0, N_CATPAD_MSG_UNICODE_NIL );
		n_txt_set( &n_catpad_config_combo_charset.txt, 1, N_CATPAD_MSG_UNICODE_LIL );
		n_txt_set( &n_catpad_config_combo_charset.txt, 2, N_CATPAD_MSG_UNICODE_BIG );
		n_txt_set( &n_catpad_config_combo_charset.txt, 3, N_CATPAD_MSG_UNICODE_UTF );

		if ( unicode == N_TXT_UNICODE_NIL )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_charset, N_CATPAD_MSG_UNICODE_NIL );
		} else
		if ( unicode == N_TXT_UNICODE_LIL )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_charset, N_CATPAD_MSG_UNICODE_LIL );
		} else
		if ( unicode == N_TXT_UNICODE_BIG )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_charset, N_CATPAD_MSG_UNICODE_BIG );
		} else
		if ( unicode == N_TXT_UNICODE_UTF )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_charset, N_CATPAD_MSG_UNICODE_UTF );
		}


		n_win_text_set_literal( H_LBL_1, "Newline" );

		n_txt_set( &n_catpad_config_combo_newline.txt, 0, N_CATPAD_MSG_CR   );
		n_txt_set( &n_catpad_config_combo_newline.txt, 0, N_CATPAD_MSG_LF   );
		n_txt_set( &n_catpad_config_combo_newline.txt, 0, N_CATPAD_MSG_CRLF );

		if ( newline == N_TXT_NEWLINE_CR )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_newline, N_CATPAD_MSG_CR   );
		} else
		if ( newline == N_TXT_NEWLINE_LF )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_newline, N_CATPAD_MSG_LF   );
		} else
		if ( newline == N_TXT_NEWLINE_CRLF )
		{
			n_win_combo_selection_set_by_string( &n_catpad_config_combo_newline, N_CATPAD_MSG_CRLF );
		}


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		n_catpad_flashwindow_init();

		EnableWindow( GetParent( hwnd ), n_false );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }
		if ( H_CAUTION != di->hwndItem ) { break; }

//n_win_scrollbar_debug_count( &n_pentrainer_config_htxt.vscr );


		HWND hgui = di->hwndItem;
		RECT rect = di->rcItem;

		n_type_gfx x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );

		n_posix_char str[ 100 ];
		n_win_text_get( hgui, str, 100 );

		COLORREF color_bg = RGB(   0,  0,  0 );
		COLORREF color_fg = RGB( 255,255,  0 );

		u32 argb_bg = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_bg ) );


		HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );


		n_win_box( hgui, hdc, &rect, argb_bg );

		if ( n_win_fluent_ui_onoff )
		{
			u32 color_corner = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );

			n_type_gfx round = n_win_fluent_ui_round_param( hwnd );
			n_bmp_cornermask( &n_gdi_doublebuffer_32bpp_instance.bmp, round, 0, color_corner );
		} else {
			n_win_frame( hdc, x,y,sx,sy, RGB( 255,255,255 ) );
		}


		HFONT hf = n_win_font_get( hgui );
		HFONT pf = SelectObject( hdc, hf );


		SetBkMode   ( hdc, TRANSPARENT );
		SetTextColor( hdc,    color_fg );

		int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		DrawText( hdc, str,-1, &rect, dt );


		SelectObject( hdc, pf );


		n_gdi_doublebuffer_32bpp_simple_exit();

	}
	break;


	case WM_COMMAND :

		if ( (HWND) lparam == n_catpad_config_combo_charset.input.hwnd )
		{
			n_catpad_flashwindow_refresh();
		} else
		if ( (HWND) lparam == n_catpad_config_combo_newline.input.hwnd )
		{
			n_catpad_flashwindow_refresh();
		}

	break;


	case WM_CLOSE :
	{

		n_win_stdfont_exit( hgui, GUI_MAX );


		n_posix_char *str;


		int new_unicode = unicode;
		int new_newline = newline;


		str = n_win_combo_selection_get( &n_catpad_config_combo_charset );

		if ( n_string_is_same( str, N_CATPAD_MSG_UNICODE_NIL ) )
		{
			new_unicode = N_TXT_UNICODE_NIL;
		} else
		if ( n_string_is_same( str, N_CATPAD_MSG_UNICODE_LIL ) )
		{
			new_unicode = N_TXT_UNICODE_LIL;
		} else
		if ( n_string_is_same( str, N_CATPAD_MSG_UNICODE_BIG ) )
		{
			new_unicode = N_TXT_UNICODE_BIG;
		} else
		if ( n_string_is_same( str, N_CATPAD_MSG_UNICODE_UTF ) )
		{
			new_unicode = N_TXT_UNICODE_UTF;
		}


		str = n_win_combo_selection_get( &n_catpad_config_combo_newline );

		if ( n_string_is_same( str, N_CATPAD_MSG_CR   ) )
		{
			new_newline = N_TXT_NEWLINE_CR;
		} else
		if ( n_string_is_same( str, N_CATPAD_MSG_LF   ) )
		{
			new_newline = N_TXT_NEWLINE_LF;
		} else
		if ( n_string_is_same( str, N_CATPAD_MSG_CRLF ) )
		{
			new_newline = N_TXT_NEWLINE_CRLF;
		}


		EnableWindow( GetParent( hwnd ), n_true );
		ShowWindow( hwnd, SW_HIDE );


		n_catpad_flashwindow_exit();


		if (
			( unicode != new_unicode )
			||
			( newline != new_newline )
		)
		{

			n_catpad_txtbox_editor.txt.unicode = new_unicode;
			n_catpad_txtbox_editor.txt.newline = new_newline;

			n_catpad_status_refresh();
			n_catpad_overwrite_onoff( n_true );

		}


		n_win_combo_exit( &n_catpad_config_combo_charset );
		n_win_combo_exit( &n_catpad_config_combo_newline );


		DestroyWindow( hwnd );

	}
	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &n_catpad_config_combo_charset );
	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &n_catpad_config_combo_newline );


	n_catpad_flashwindow_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_CAUTION
#undef H_LBL_0
#undef H_LBL_1
#undef GUI_MAX

