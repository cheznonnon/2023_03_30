// Nonnon Sound Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : shared mode has bug : error will occur




#include "../../nonnon/win32/mixer.c"


const GUID n_wasapi_IID_IAudioClient       = { 0x1CB9AD4C,0xDBFA,0x4c32,{ 0xB1,0x78, 0xC2,0xF5,0x68,0xA7,0x03,0xB2 } };
const GUID n_wasapi_IID_IAudioRenderClient = { 0xF294ACFC,0x3146,0x4483,{ 0xA7,0xBF, 0xAD,0xDC,0xA7,0xC2,0x60,0xE2 } };




#ifdef _MSC_VER


#include <mmreg.h>
#include <Audioclient.h>


#else // #ifdef _MSC_VER


#ifndef _INC_MMREG


const GUID KSDATAFORMAT_SUBTYPE_PCM = { 0x00000001,0x0000,0x0010,{ 0x80,0x00, 0x00,0xaa,0x00,0x38,0x9b,0x71 } };


typedef struct {
	WAVEFORMATEX Format;
	union {
		WORD wValidBitsPerSample;
		WORD wSamplesPerBlock;
		WORD wReserved;
	} Samples;
	DWORD        dwChannelMask;
	GUID         SubFormat;
} WAVEFORMATEXTENSIBLE, *PWAVEFORMATEXTENSIBLE;


#define SPEAKER_FRONT_LEFT  0x1
#define SPEAKER_FRONT_RIGHT 0x2


#endif // #ifndef _INC_MMREG


#ifndef __audioclient_h__


#define REFERENCE_TIME LONGLONG

typedef enum _AUDCLNT_SHAREMODE
{
	AUDCLNT_SHAREMODE_SHARED,
	AUDCLNT_SHAREMODE_EXCLUSIVE
} AUDCLNT_SHAREMODE;


EXTERN_C const IID IID_IAudioClient;
#define INTERFACE IAudioClient
DECLARE_INTERFACE_( IAudioClient, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS                 ) PURE;
	STDMETHOD_( ULONG, Release )( THIS                 ) PURE;

	STDMETHOD( Initialize        )( THIS_ AUDCLNT_SHAREMODE, DWORD, REFERENCE_TIME, REFERENCE_TIME, WAVEFORMATEX*, LPCGUID ) PURE;
	STDMETHOD( GetBufferSize     )( THIS_ UINT32* ) PURE;
	STDMETHOD( GetStreamLatency  )( THIS_ REFERENCE_TIME* ) PURE;
	STDMETHOD( GetCurrentPadding )( THIS_ UINT32* ) PURE;
	STDMETHOD( IsFormatSupported )( THIS_ AUDCLNT_SHAREMODE, WAVEFORMATEX*, WAVEFORMATEX** ) PURE;
	STDMETHOD( GetMixFormat      )( THIS_ WAVEFORMATEX** ) PURE;
	STDMETHOD( GetDevicePeriod   )( THIS_ REFERENCE_TIME*, REFERENCE_TIME* ) PURE;
	STDMETHOD( Start             )( THIS ) PURE;
	STDMETHOD( Stop              )( THIS ) PURE;
	STDMETHOD( Reset             )( THIS ) PURE;
	STDMETHOD( SetEventHandle    )( THIS_ HANDLE ) PURE;
	STDMETHOD( GetService        )( THIS_ REFIID, void** ) PURE;
};
#undef INTERFACE

#define IAudioClient_QueryInterface( p, a,b ) (p)->lpVtbl->QueryInterface( p, a,b )
#define IAudioClient_AddRef(         p      ) (p)->lpVtbl->AddRef(         p      )
#define IAudioClient_Release(        p      ) (p)->lpVtbl->Release(        p      )
#define IAudioClient_Initialize(        p, a,b,c,d,e,f ) (p)->lpVtbl->Initialize(        p, a,b,c,d,e,f )
#define IAudioClient_GetBufferSize(     p, a           ) (p)->lpVtbl->GetBufferSize(     p, a           )
#define IAudioClient_GetStreamLatency(  p, a           ) (p)->lpVtbl->GetStreamLatency(  p, a           )
#define IAudioClient_GetCurrentPadding( p, a           ) (p)->lpVtbl->GetCurrentPadding( p, a           )
#define IAudioClient_IsFormatSupported( p, a,b,c       ) (p)->lpVtbl->IsFormatSupported( p, a,b,c       )
#define IAudioClient_GetMixFormat(      p, a           ) (p)->lpVtbl->GetMixFormat(      p, a           )
#define IAudioClient_GetDevicePeriod(   p, a,b         ) (p)->lpVtbl->GetDevicePeriod(   p, a,b         )
#define IAudioClient_Start(             p              ) (p)->lpVtbl->Start(             p              )
#define IAudioClient_Stop(              p              ) (p)->lpVtbl->Stop(              p              )
#define IAudioClient_Reset(             p              ) (p)->lpVtbl->Reset(             p              )
#define IAudioClient_SetEventHandle(    p, a           ) (p)->lpVtbl->SetEventHandle(    p, a           )
#define IAudioClient_GetService(        p, a,b         ) (p)->lpVtbl->GetService(        p, a,b         )


EXTERN_C const IID IID_IAudioRenderClient;
#define INTERFACE IAudioRenderClient
DECLARE_INTERFACE_( IAudioRenderClient, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS                 ) PURE;
	STDMETHOD_( ULONG, Release )( THIS                 ) PURE;

	STDMETHOD( GetBuffer       )( THIS_ UINT32, BYTE** ) PURE;
	STDMETHOD( ReleaseBuffer   )( THIS_ UINT32, DWORD  ) PURE;
};
#undef INTERFACE

#define IAudioRenderClient_QueryInterface( p, a,b ) (p)->lpVtbl->QueryInterface( p, a,b )
#define IAudioRenderClient_AddRef(         p      ) (p)->lpVtbl->AddRef(         p      )
#define IAudioRenderClient_Release(        p      ) (p)->lpVtbl->Release(        p      )
#define IAudioRenderClient_GetBuffer(      p, a,b ) (p)->lpVtbl->GetBuffer(      p, a,b )
#define IAudioRenderClient_ReleaseBuffer(  p, a,b ) (p)->lpVtbl->ReleaseBuffer(  p, a,b )


#endif // #ifndef __audioclient_h__


#endif // #ifdef _MSC_VER




typedef struct {

	int a;

} n_wasapi;


#define n_wasapi_zero( p ) n_memory_zero( p, sizeof( n_wasapi ) )



void
n_wasapi_exit( n_wasapi *p )
{

	CoUninitialize();

	return;
}

n_posix_bool
n_wasapi_init( n_wasapi *p, n_wav *wav )
{

	HRESULT hr;


	IMMDeviceEnumerator *IMMDeviceEnumerator = NULL;
	IMMDevice           *IMMDevice           = NULL;
	IAudioClient        *IAudioClient        = NULL;
	IAudioRenderClient  *IAudioRenderClient  = NULL;


	CoInitialize( NULL );


	hr = CoCreateInstance
	(
		&n_mixer_CLSID_MMDeviceEnumerator,
		NULL,
		CLSCTX_ALL,
		&n_mixer_IID_IUnknown,
		(void*) &IMMDeviceEnumerator
	);

	if ( FAILED( hr )||( IMMDeviceEnumerator == NULL ) )
	{
n_posix_debug_literal( " CoCreateInstance() " );

		return n_posix_true;
	}


	hr = IMMDeviceEnumerator_GetDefaultAudioEndpoint
	(
		IMMDeviceEnumerator,
		eRender,
		eConsole,
		(void*) &IMMDevice
	);

	if ( FAILED( hr )||( IMMDevice == NULL ) )
	{
n_posix_debug_literal( " IMMDeviceEnumerator_GetDefaultAudioEndpoint() " );

		IMMDeviceEnumerator_Release( IMMDeviceEnumerator );

		return n_posix_true;
	}


	hr = IMMDevice_Activate
	(
		IMMDevice,
		&n_wasapi_IID_IAudioClient,
		CLSCTX_ALL,
		NULL,
		(void*) &IAudioClient
	);

	if ( FAILED( hr )||( IAudioClient == NULL ) )
	{
n_posix_debug_literal( "IMMDevice_Activate" );

		IMMDevice_Release          ( IMMDevice           );
		IMMDeviceEnumerator_Release( IMMDeviceEnumerator );

		return n_posix_true;
	}

/*
	// [!] : WAVEFORMATEX : error when AUDCLNT_SHAREMODE_SHARED

	hr = IAudioClient_IsFormatSupported
	(
		IAudioClient,
		AUDCLNT_SHAREMODE_EXCLUSIVE,
		&wav->fmt,
		NULL
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioClient_IsFormatSupported" );
	}
*/

	WAVEFORMATEX *ptr_wavefromatex = NULL;
	IAudioClient_GetMixFormat( IAudioClient, &ptr_wavefromatex );
/*
n_posix_debug_literal
(
	"%d %d %d %d %d %d %d\n"
	"%d %d %d %d %d %d %d",
	ptr_wavefromatex->wFormatTag,
	ptr_wavefromatex->nChannels,
	ptr_wavefromatex->nSamplesPerSec,
	ptr_wavefromatex->nAvgBytesPerSec,
	ptr_wavefromatex->nBlockAlign,
	ptr_wavefromatex->wBitsPerSample,
	ptr_wavefromatex->cbSize,
	wav->fmt.wFormatTag,
	wav->fmt.nChannels,
	wav->fmt.nSamplesPerSec,
	wav->fmt.nAvgBytesPerSec,
	wav->fmt.nBlockAlign,
	wav->fmt.wBitsPerSample,
	wav->fmt.cbSize
);
*/
/*
	// [x] : error

	ptr_wavefromatex->nChannels       = wav->fmt.nChannels;
	ptr_wavefromatex->nSamplesPerSec  = wav->fmt.nSamplesPerSec;
	ptr_wavefromatex->nAvgBytesPerSec = wav->fmt.nAvgBytesPerSec;
	ptr_wavefromatex->nBlockAlign     = wav->fmt.nBlockAlign;
	ptr_wavefromatex->wBitsPerSample  = wav->fmt.wBitsPerSample;
*/
/*
	// [x] : error

	WAVEFORMATEX wave_format; n_memory_zero( &wave_format, sizeof( WAVEFORMATEX ) );

	wave_format.wFormatTag      = WAVE_FORMAT_PCM;
	wave_format.nChannels       = 2;
	wave_format.nSamplesPerSec  = 44100;
	wave_format.nAvgBytesPerSec = 44100 * 2 * 16 / 8;
	wave_format.nBlockAlign     = 2 * 16 / 8;
	wave_format.wBitsPerSample  = 16;
*/
	hr = IAudioClient_Initialize
	(
		IAudioClient,
		AUDCLNT_SHAREMODE_SHARED,
		0,
		10000000,
		0,
		ptr_wavefromatex,
		NULL
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioClient_Initialize" );

		IAudioClient_Release       ( IAudioClient        );
		IMMDevice_Release          ( IMMDevice           );
		IMMDeviceEnumerator_Release( IMMDeviceEnumerator );

		return n_posix_true;
	}


	UINT32 buffer_frame_count;
	IAudioClient_GetBufferSize( IAudioClient, &buffer_frame_count );
n_posix_debug_literal( "%d", buffer_frame_count );


	hr = IAudioClient_GetService
	(
		IAudioClient,
		&n_wasapi_IID_IAudioRenderClient,
		(void*) &IAudioRenderClient
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioClient_GetService" );

		IAudioClient_Release       ( IAudioClient        );
		IMMDevice_Release          ( IMMDevice           );
		IMMDeviceEnumerator_Release( IMMDeviceEnumerator );

		return n_posix_true;
	}


	BYTE *ptr_byte;

	hr = IAudioRenderClient_GetBuffer
	(
		IAudioRenderClient,
		buffer_frame_count,
		&ptr_byte
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioRenderClient_GetBuffer" );
	}

	LONG        *l = (void*) ptr_byte;
	LONG         e = buffer_frame_count / ptr_wavefromatex->nBlockAlign;
	n_type_real  d;

	int i = 0;
	while( 1 )
	{

		d = (n_type_real) i / 2;
		d = cos( 2 * M_PI * d );
		d = LONG_MAX * d;

		l[ i + 0 ] = l[ i + 1 ] = d;

		i += 2;
		if ( i >= e ) { break; }
	}

	hr = IAudioRenderClient_ReleaseBuffer
	(
		IAudioRenderClient,
		buffer_frame_count,
		0
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioRenderClient_ReleaseBuffer" );
	}


	hr = IAudioClient_Start( IAudioClient );

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IAudioClient_Start" );
	}


	n_posix_sleep( 1000 );


	IAudioRenderClient_Release ( IAudioRenderClient  );
	IAudioClient_Release       ( IAudioClient        );
	IMMDevice_Release          ( IMMDevice           );
	IMMDeviceEnumerator_Release( IMMDeviceEnumerator );


	return FAILED( hr );
}

void
n_wasapi_loop( n_wasapi *p )
{

	return;
}

void
n_wasapi_stop( n_wasapi *p )
{

	return;
}

void
n_wasapi_pause( n_wasapi *p )
{

	return;
}

void
n_wasapi_resume( n_wasapi *p )
{

	return;
}


