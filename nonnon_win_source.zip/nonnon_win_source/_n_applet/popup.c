// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_popup.c"

#include "../nonnon/project/macro.c"




#define H_BTN_L hbtn[ 0 ]
#define H_BTN_M hbtn[ 1 ]
#define H_BTN_R hbtn[ 2 ]
#define BTN_MAX       3




LRESULT CALLBACK
n_applet_popup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_button hbtn[ BTN_MAX ];

	static HICON icon_ie, icon_cpl;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		n_win_button_on_settingchange( &H_BTN_L );
		n_win_button_on_settingchange( &H_BTN_M );
		n_win_button_on_settingchange( &H_BTN_R );

		H_BTN_L.maclike_onoff = n_posix_false;
		H_BTN_M.maclike_onoff = n_posix_false;
		H_BTN_R.maclike_onoff = n_posix_false;

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_button_zero( &H_BTN_L );
		n_win_button_zero( &H_BTN_M );
		n_win_button_zero( &H_BTN_R );

		n_project_darkmode();


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		n_win_button_init( &H_BTN_L, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_M, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_R, hwnd, N_STRING_EMPTY, PBS_NORMAL );

		H_BTN_L.maclike_onoff = n_posix_false;
		H_BTN_M.maclike_onoff = n_posix_false;
		H_BTN_R.maclike_onoff = n_posix_false;


		// Style

		n_win_style_new( hwnd, WS_POPUP );
		n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );


		icon_ie  = n_ie_icon();
		icon_cpl = n_ie_icon_controlpanel();

		H_BTN_L.hicon = icon_ie;
		H_BTN_M.hicon = icon_cpl;
		H_BTN_R.hicon = n_win_icon_init_literal( "./n_applet.exe", 1, N_WIN_ICON_INIT_OPTION_DEFAULT );


		// Size

		{

		const n_bool redraw = n_false;


		n_type_gfx ico,m;
		n_type_gfx csx,csy;


		n_win_stdsize( hwnd, NULL, &ico, &m );

		ico = ico + ( m * 2 );
		csx = ico * BTN_MAX;
		csy = ico;

		n_win_popup_automove( hwnd, csx,csy );

		n_win_move_simple( H_BTN_L.hwnd, 0*ico,0, ico,ico, redraw );
		n_win_move_simple( H_BTN_M.hwnd, 1*ico,0, ico,ico, redraw );
		n_win_move_simple( H_BTN_R.hwnd, 2*ico,0, ico,ico, redraw );

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_BTN_L.hwnd )
		{

			n_ie_call();

		} else
		if ( h == H_BTN_M.hwnd )
		{

			n_posix_char *inetcpl = n_posix_literal( "rundll32 shell32.dll,Control_RunDLL inetcpl.cpl,,1" );

			n_win_exec( inetcpl, SW_NORMAL );

		} else
		if ( h == H_BTN_R.hwnd )
		{

			n_inetcpl_extremehigh();

			break;

		}

		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_button_exit( &H_BTN_L );
		n_win_button_exit( &H_BTN_M );
		n_win_button_exit( &H_BTN_R );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		if ( sticky ) { break; }

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_L );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_M );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_R );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef BTN_MAX
#undef H_BTN_L
#undef H_BTN_M
#undef H_BTN_R

